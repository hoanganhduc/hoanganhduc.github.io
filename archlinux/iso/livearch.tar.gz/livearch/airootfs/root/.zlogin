~/.automated_script.sh
