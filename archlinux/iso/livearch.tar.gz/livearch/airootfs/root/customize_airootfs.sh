#!/bin/bash

set -e -u

sed -i 's/#\(en_US\.UTF-8\)/\1/' /etc/locale.gen
locale-gen

ln -sf /usr/share/zoneinfo/UTC /etc/localtime

usermod -s /usr/bin/zsh root
cp -aT /etc/skel/ /root/
chmod 700 /root

sed -i 's/#\(PermitRootLogin \).\+/\1yes/' /etc/ssh/sshd_config
sed -i "s/#Server/Server/g" /etc/pacman.d/mirrorlist
sed -i 's/#\(Storage=\)auto/\1volatile/' /etc/systemd/journald.conf

sed -i 's/#\(HandleSuspendKey=\)suspend/\1ignore/' /etc/systemd/logind.conf
sed -i 's/#\(HandleHibernateKey=\)hibernate/\1ignore/' /etc/systemd/logind.conf
sed -i 's/#\(HandleLidSwitch=\)suspend/\1ignore/' /etc/systemd/logind.conf

systemctl enable pacman-init.service choose-mirror.service
#systemctl set-default multi-user.target
systemctl set-default graphical.target

echo "Creating user livearch"
! id livearch && useradd -m -p "" -c "LiveArch" -G "adm,ftp,games,http,locate,floppy,input,log,network,rfkill,scanner,storage,optical,power,wheel,users,docker" -s /usr/bin/zsh livearch
echo "livearch ALL=(ALL) NOPASSWD:ALL" >> /etc/sudoers

echo "Extracting files"
tar xvf /root/custom_files.tar.gz -C / && rm -rf /root/custom_files.tar.gz

echo "Set default Java version"
archlinux-java set java-11-openjdk

echo "Commenting out option CheckSpace in /etc/pacman.conf"
sed -i "s/CheckSpace/#CheckSpace/g" /etc/pacman.conf

echo "Installing extra packages"
su - livearch -c "yay -Syy && yay -S --needed --noconfirm freeoffice eclipse-java skypeforlinux-stable-bin && yes | yay -Scc" 

echo "Enabling some services"
systemctl enable gdm bluetooth NetworkManager org.cups.cupsd.service ufw sshd teamviewerd docker httpd php-fpm bitlbee vsftpd vsftpd_ssl postfix dovecot mysqld 

echo "Enabling ufw firewall"
ufw enable

echo "Change owners"
chown -R livearch:livearch /home/livearch

echo "Restoring GNOME settings"
su - livearch -c "dbus-launch dconf load / < arch-gnome-full-backup && rm -rf arch-gnome-full-backup"

echo "Installing zotero-cli"
pip install zotero-cli

echo "Installing Blackarch"
curl -O https://blackarch.org/strap.sh && chmod +x strap.sh && ./strap.sh && rm -rf strap.sh

echo "Installing some rubygems"
su - livearch -c "gem install bundler && export PATH=/home/livearch/.gem/ruby/2.6.0/bin:$PATH && bundle install && rm -rf Gemfile*"

echo "Installing doconce to a python2 virtualenv"
su - livearch -c "source /usr/bin/virtualenvwrapper_lazy.sh && mkdir -p /home/livearch/.virtualenvs && mkvirtualenv -p /usr/bin/python2.7 doconce && workon doconce && pip install --upgrade pip && pip install setuptools ipython tornado pyzmq traitlets pickleshare jsonschema pdftools future mako python-Levenshtein lxml sphinx && git clone https://github.com/hoanganhduc/preprocess && cd preprocess && python setup.py install && cd .. && rm -rf preprocess && git clone https://github.com/hoanganhduc/logg-publish && cd logg-publish && python setup.py install && cd .. && rm -rf logg-publish && git clone https://github.com/hoanganhduc/doconce.git && cd doconce && python setup.py install && cd .. && rm -rf doconce && deactivate"

echo "Installing poppler 0.59.0 from source"
su - livearch -c "curl -O https://poppler.freedesktop.org/poppler-0.59.0.tar.xz && tar -xvf poppler-0.59.0.tar.xz && cd poppler-0.59.0/ && ./configure --prefix=/usr/local --enable-xpdf-headers && make && sudo make install && sudo ln -sf /usr/local/lib/libpoppler.so.70 /usr/lib/libpoppler.so.70 && cd .. && rm -rf poppler-0.59.0*"

echo "Installing libsodium 0.7.1 from source"
su - livearch -c "curl -O https://download.libsodium.org/libsodium/releases/old/unsupported/libsodium-0.7.1.tar.gz && tar xvf libsodium-0.7.1.tar.gz  && cd libsodium-0.7.1 && ./configure --prefix=/usr/local && make && sudo make install && sudo ln -sf /usr/local/lib/libsodium.so.13 /usr/lib/libsodium.so.13 && cd .. && rm -rf libsodium-0.7.1*"

echo "Updating fonts cache for livearch"
su - livearch -c "fc-cache -fv"

echo "Restoring option CheckSpace in /etc/pacman.conf"
sed -i "s/#CheckSpace/CheckSpace/g" /etc/pacman.conf

echo "Cleaning up"
su - livearch -c "rm -rf /home/livearch/.zsh_history /home/livearch/.bash_history"
rm -rf /root/.zsh_history /root/.bash_history
