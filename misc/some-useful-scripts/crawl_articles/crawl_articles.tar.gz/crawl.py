#!/usr/bin/python
# Last Modified: 2025-01-10
# Description: A Python script to crawl articles from various databases based on user-selected keywords.
# -*- coding: utf-8 -*-
import re
import sys
from crawl_articles import main
if __name__ == '__main__':
    sys.argv[0] = re.sub(r'(-script\.pyw|\.exe)?$', '', sys.argv[0])
    sys.exit(main())