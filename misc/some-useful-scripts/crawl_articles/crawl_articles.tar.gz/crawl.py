# Last Modified: 2025-01-08
# Description: A Python script to crawl articles from various databases based on user-selected keywords.

# -*- coding: utf-8 -*-

from crawl_articles import *

# Main function to execute the script
def main():
    """
    Main function to handle the process of fetching and saving articles based on user-defined or default settings.
    This function performs the following steps:
    1. Parses command-line arguments.
    2. Handles each argument separately.
    """
    start_time = time.time()
    
    # Print welcome message and briefly explain what the script does
    print_welcome_message()
    
    # Parse command-line arguments
    args = parse_arguments()
    
    # Validate the parsed arguments
    try:
        validate_arguments(args)
    except ValueError as e:
        print(f"Argument validation error: {e}")
        sys.exit(1)
        
    # Enable debug mode if specified
    if args.debug:
        enable_debug_mode()

    # Handle the argument to print default keywords
    if args.print_default_keywords:
        handle_print_default_keywords()
        return

    # Handle the argument to clean up generated files
    if args.clean:
        handle_clean_generated_files()
        return

    # Use default settings if specified, otherwise get user settings
    if args.default:
        all_keywords, selected_keywords, years, databases, additional_sources, limit, output_format = use_default_settings()
    else:
        all_keywords, selected_keywords, years, databases, additional_sources, limit, output_format = get_user_settings(args)

    # Combine default and additional data sources
    all_data_sources = data_sources + additional_sources
    
    # Fetch existing titles from the data sources
    existing_titles = fetch_existing_titles(all_data_sources, args.cache, args.verbose)
    
    # Fetch articles from all specified databases synchronously
    all_articles = fetch_all_articles(selected_keywords, existing_titles, years, databases, limit, args.verbose)

    # Print the total number of articles found
    print(f"Total number of articles found: {len(all_articles)}")

    # Generate a timestamp for file naming
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")

    # Save the fetched articles to files in the specified formats
    save_articles_to_files(all_articles, output_format, args.verbose, timestamp)

    # Handle the argument to upload generated files
    if args.upload:
        filenames = [f'articles_{timestamp}.bib', f'articles_{timestamp}.html', f'articles_{timestamp}.pdf']
        existing_files = [filename for filename in filenames if os.path.exists(filename)]
        if existing_files:
            handle_upload_files(args.upload, existing_files, args.verbose)
        else:
            print("No files were generated to ")

    # Print environment and resource usage information
    print_environment_info(start_time, args.verbose)

if __name__ == "__main__":
    main()
