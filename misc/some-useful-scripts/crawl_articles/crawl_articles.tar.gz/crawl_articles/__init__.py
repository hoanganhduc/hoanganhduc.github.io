import os
import glob
import importlib.util

"""
This is the crawl_articles package.

This package is responsible for crawling and processing articles.
"""

# Get the current directory
current_dir = os.path.dirname(__file__)

# Find all Python files in the current directory
modules = glob.glob(os.path.join(current_dir, "*.py"))

# Import all functions from all modules and make them global using absolute import
for module in modules:
    if os.path.isfile(module) and not module.endswith('__init__.py'):
        module_name = os.path.basename(module)[:-3]
        module_path = f"{__package__}.{module_name}"
        spec = importlib.util.find_spec(module_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        for attr in dir(mod):
            if not attr.startswith('_'):
                globals()[attr] = getattr(mod, attr)