import os
import glob
import importlib.util

"""
This is the crawl_articles package.

This package is responsible for crawling and processing articles.
"""

# Get the current directory
current_dir = os.path.dirname(__file__)

# Find all Python files in the current directory
modules = glob.glob(os.path.join(current_dir, "*.py"))

# Import all functions from all modules and make them global using absolute import
for module in modules:
    if os.path.isfile(module) and not module.endswith('__init__.py'):
        module_name = os.path.basename(module)[:-3]
        module_path = f"{__package__}.{module_name}"
        spec = importlib.util.find_spec(module_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        for attr in dir(mod):
            if not attr.startswith('_'):
                globals()[attr] = getattr(mod, attr)

# Main function to execute the script
def main():
    """
    Main function to handle the process of fetching and saving articles based on user-defined or default settings.
    This function performs the following steps:
    1. Parses command-line arguments.
    2. Handles each argument separately.
    """
    start_time = time.time()
    
    # Print welcome message and briefly explain what the script does
    print_welcome_message()
    
    # Parse command-line arguments
    args = parse_arguments()
    
    # Validate the parsed arguments
    try:
        validate_arguments(args)
    except ValueError as e:
        print(f"Argument validation error: {e}")
        sys.exit(1)
        
    # Enable debug mode if specified
    if args.debug:
        enable_debug_mode()

    # Handle the argument to print default keywords
    if args.print_default_keywords:
        handle_print_default_keywords()
        return

    # Handle the argument to clean up generated files
    if args.clean:
        handle_clean_generated_files()
        return

    # Use default settings if specified, otherwise get user settings
    if args.default:
        all_keywords, selected_keywords, years, databases, additional_sources, limit, output_format = use_default_settings()
    else:
        all_keywords, selected_keywords, years, databases, additional_sources, limit, output_format = get_user_settings(args)

    # Combine default and additional data sources
    all_data_sources = data_sources + additional_sources
    
    # Fetch existing titles from the data sources
    existing_titles = fetch_existing_titles(all_data_sources, args.cache, args.verbose)
    
    if args.async_fetch:
        # Fetch articles from all specified databases asynchronously
        all_articles = run_asyncio_task(async_fetch_all_articles(selected_keywords, existing_titles, years, databases, limit, args.verbose, args.cache))
    else:
        # Fetch articles from all specified databases synchronously
        all_articles = fetch_all_articles(selected_keywords, existing_titles, years, databases, limit, args.verbose, args.cache)

    # Print the total number of articles found
    print(f"Total number of articles found: {len(all_articles)}")

    # Generate a timestamp for file naming
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")

    # Save the fetched articles to files in the specified formats
    save_articles_to_files(all_articles, output_format, args.verbose, timestamp)

    # Handle the argument to upload generated files
    if args.upload:
        filenames = [f'articles_{timestamp}.bib', f'articles_{timestamp}.html', f'articles_{timestamp}.pdf']
        existing_files = [filename for filename in filenames if os.path.exists(filename)]
        if existing_files:
            handle_upload_files(args.upload, existing_files, args.verbose)
        else:
            print("No files were generated to ")

    # Print environment and resource usage information
    print_environment_info(start_time, args.verbose)

# If this script is executed directly, call the main function
if __name__ == "__main__":
    main()