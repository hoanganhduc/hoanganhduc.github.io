"""
This module provides asynchronous functions to fetch and process articles from various academic databases 
including arXiv, DBLP, Semantic Scholar, Google Scholar, zbMATH, and CrossRef. The functions are designed 
to search for articles based on specific keywords, filter them by existing titles and publication years, 
and return a list of articles with details such as id, title, author, journal, year, url, and doi.

Functions:
    async_fetch_arxiv_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose=False, use_cache=False):
        Fetch and process articles for a specific keyword from arXiv.
    async_fetch_arxiv_articles(keywords, existing_titles, years, limit=20, verbose=False, use_cache=False):
        Fetch articles from arXiv based on keywords and filter by existing titles and years.
    async_fetch_dblp_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose=False, use_cache=False):
        Fetch and process articles for a specific keyword from DBLP.
    async_fetch_dblp_articles(keywords, existing_titles, years, limit=20, verbose=False, use_cache=False):
        Fetch articles from DBLP based on keywords and filter by existing titles and years.
    async_fetch_semantic_scholar_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose=False, use_cache=False):
        Fetch and process articles for a specific keyword from Semantic Scholar.
    async_fetch_semantic_scholar_articles(keywords, existing_titles, years, limit=20, verbose=False, use_cache=False):
        Fetch articles from Semantic Scholar based on keywords and filter by existing titles and years.
    async_fetch_google_scholar_keyword(keyword, limit, existing_titles, titles_seen, current_year, years, articles, verbose=False, use_cache=False):
        Fetch and process articles for a specific keyword from Google Scholar.
    async_fetch_google_scholar_articles(keywords, existing_titles, years, limit=20, verbose=False, use_cache=False):
        Fetch articles from Google Scholar based on keywords and filter by existing titles and years.
    async_fetch_zbmath_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose=False, use_cache=False):
        Fetch and process articles for a specific keyword from zbMATH.
    async_fetch_zbmath_articles(keywords, existing_titles, years, limit=20, verbose=False, use_cache=False):
        Fetch articles from zbMATH based on keywords and filter by existing titles and years.
    async_fetch_crossref_keyword(keyword, limit, existing_titles, titles_seen, current_year, years, articles, verbose=False, use_cache=False):
        Fetch and process articles for a specific keyword from CrossRef using crossrefapi.
    async_fetch_crossref_articles(keywords, existing_titles, years, limit=20, verbose=False, use_cache=False):
        Fetch articles from CrossRef based on keywords and filter by existing titles and years.
    async_fetch_all_articles(selected_keywords, existing_titles, years, databases, limit, verbose=False, use_cache=False):
        Fetch articles from all specified databases concurrently.
"""

import aiohttp
import asyncio
from .crawl_data import *

# Runs an asyncio task in the current event loop. If no event loop is running, it creates a new one
def run_asyncio_task(task):
    """
    Runs an asyncio task in the current event loop. If no event loop is running, it creates a new one.

    Args:
        task (coroutine): The asyncio task to be run.

    Returns:
        The result of the completed task.

    Raises:
        RuntimeError: If the event loop is closed.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    return loop.run_until_complete(task)

# Test connection to a database by sending a request with a test keyword asynchronously.
async def async_test_database_connection(database_name, base_url=None, test_keyword="reconfiguration", verbose=False):
    """
    Test connection to a database by sending a request with a test keyword asynchronously.

    Args:
        database_name (str): The name of the database.
        base_url (str, optional): The base URL for the database API. Defaults to None.
        test_keyword (str, optional): A keyword to use for testing the connection. Defaults to "reconfiguration".
        verbose (bool, optional): If True, print additional logs. Defaults to False.

    Returns:
        bool: True if the connection is successful, False otherwise.
    """
    if verbose:
        print(f"Testing connection to the {database_name} database...")
    try:
        if database_name == "arXiv":
            base_url = "http://export.arxiv.org/api/query?search_query=all:{}&start=0&max_results={}"
        elif database_name == "DBLP":
            base_url = "https://dblp.org/search/publ/api?q={}&h={}&format=json"
        elif database_name == "Semantic Scholar":
            base_url = "https://api.semanticscholar.org/graph/v1/paper/search/bulk?query={}&limit={}"
        elif database_name == "zbMATH":
            base_url = "https://api.zbmath.org/v1/document/_search?search_string={}&page=0&results_per_page={}&sort=year:desc"
        elif database_name == "CrossRef":
            base_url = None  # CrossRef uses a different method for testing connection
        elif database_name == "Google Scholar":
            base_url = None  # Google Scholar uses a different method for testing connection
        elif base_url is None:
            if verbose:
                print(f"Base URL is required for database '{database_name}'")
            return False

        if database_name == "CrossRef":
            works = Works()
            results = works.query(test_keyword).sort("relevance").sample(1).all({})
            if results:
                if verbose:
                    print(f"Successfully connected to the {database_name} database")
                return True
            else:
                if verbose:
                    print(f"Failed to connect to the {database_name} database")
                return False
        elif database_name == "Google Scholar":
            try:
                search_query = scholarly.search_pubs(test_keyword)
                next(search_query)
                if verbose:
                    print(f"Successfully connected to the {database_name} database")
                return True
            except Exception as e:
                if verbose:
                    print(f"Failed to connect to the {database_name} database: {e}")
                return False
        else:
            async with aiohttp.ClientSession() as session:
                async with session.get(base_url.format(test_keyword.lower().replace(" ", "+"), 1)) as response:
                    if response.status == 200:
                        if verbose:
                            print(f"Successfully connected to the {database_name} database")
                        return True
                    else:
                        if verbose:
                            print(f"Failed to connect to the {database_name} database at {base_url}. Status code: {response.status}")
                        return False
    except Exception as e:
        if verbose:
            print(f"An error occurred while testing connection to the {database_name} database: {e}")
        return False

# Fetch and process articles for a specific keyword from arXiv
async def async_fetch_arxiv_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose=False, use_cache=False):
    """
    Fetch and process articles for a specific keyword from arXiv.

    Args:
        keyword (str): The keyword to search for in arXiv.
        base_url (str): The base URL for the arXiv API.
        limit (int): Maximum number of articles to fetch per keyword.
        existing_titles (set): Set of existing article titles to filter out.
        titles_seen (set): Set of titles already seen in the current fetch.
        current_year (int): The current year.
        years (int): Number of years back to search for articles.
        articles (list): List to store fetched articles.
        verbose (bool): If True, print additional logs. Defaults to False.
        use_cache (bool, optional): If True, save found titles to cache. Defaults to False.
    """
    try:
        if verbose:
            print(f"Processing keyword '{keyword}' in arXiv")
        # Send request to arXiv API
        async with aiohttp.ClientSession() as session:
            async with session.get(base_url.format(keyword.lower().replace(" ", "+"), limit)) as response:
                response_text = await response.text()
                soup = BeautifulSoup(response_text, 'xml')
                entries = soup.find_all('entry')
                for entry in entries:
                    year = int(entry.published.text[:4])
                    title = entry.title.text
                    title_lower = title.lower().strip('{}')
                    # Skip if title already seen or too old
                    if title_lower in titles_seen or any(is_similar(title_lower, existing_title) for existing_title in existing_titles):
                        continue
                    if current_year - year <= years:
                        # Compile article information
                        article = {
                            'id': entry.id.text.split('/')[-1],
                            'title': title,
                            'author': ' and '.join([author.find('name').text for author in entry.find_all('author')]),
                            'journal': 'arXiv preprint',
                            'year': str(year),
                            'url': entry.id.text
                        }
                        # Check for DOI
                        doi_tag = entry.find('arxiv:doi', {'xmlns:arxiv': 'http://arxiv.org/schemas/atom'})
                        if doi_tag:
                            article['doi'] = doi_tag.text
                        articles.append(article)
                        titles_seen.add(title_lower)
                        if use_cache:
                            save_titles_to_cache(titles_seen, cache_file='cache.json', verbose=verbose)
    except Exception as e:
        if verbose:
            print(f"An error occurred while fetching articles for keyword '{keyword}' from arXiv: {e}")

# Fetch articles from arXiv based on keywords and filter by existing titles and years
async def async_fetch_arxiv_articles(keywords, existing_titles, years, limit=20, verbose=False, use_cache=False, max_concurrent_tasks=5):
    """
    Fetch articles from arXiv based on keywords, filtering by existing titles and years.

    Args:
        keywords (list): List of keywords to search for.
        existing_titles (set): Set of existing article titles to filter out.
        years (int): Number of years back to search for articles.
        limit (int, optional): Maximum number of articles to fetch per keyword. Defaults to 20.
        verbose (bool, optional): If True, print additional logs. Defaults to False.
        use_cache (bool, optional): If True, save found titles to cache. Defaults to False.
        max_concurrent_tasks (int, optional): Maximum number of concurrent tasks. Defaults to 5.

    Returns:
        list: A list of articles with details such as id, title, author, journal, year, url, and doi.
    """
    print("Fetching articles from arXiv...")
    base_url = "http://export.arxiv.org/api/query?search_query=all:{}&start=0&max_results={}"
    articles = []
    titles_seen = set()
    current_year = datetime.now().year

    async def fetch_keyword(keyword):
        await async_fetch_arxiv_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose, use_cache)

    semaphore = asyncio.Semaphore(max_concurrent_tasks)
    
    async def sem_fetch_keyword(keyword):
        async with semaphore:
            await fetch_keyword(keyword)

    tasks = [sem_fetch_keyword(keyword) for keyword in keywords]
    await asyncio.gather(*tasks)

    return articles

# Fetch and process articles for a specific keyword from DBLP
async def async_fetch_dblp_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose=False, use_cache=False):
    """
    Fetch and process articles for a specific keyword from DBLP.

    Args:
        keyword (str): The keyword to search for in DBLP.
        base_url (str): The base URL for the DBLP API.
        limit (int): Maximum number of articles to fetch per keyword.
        existing_titles (set): Set of existing article titles to filter out.
        titles_seen (set): Set of titles already seen in the current fetch.
        current_year (int): The current year.
        years (int): Number of years back to search for articles.
        articles (list): List to store fetched articles.
        verbose (bool): If True, print additional logs. Defaults to False.
        use_cache (bool, optional): If True, save found titles to cache. Defaults to False.
    """
    try:
        if verbose:
            print(f"Processing keyword '{keyword}' in DBLP")
        # Send request to DBLP API
        async with aiohttp.ClientSession() as session:
            async with session.get(base_url.format(keyword.lower().replace(" ", "+"), limit)) as response:
                if response.status != 200:
                    if verbose:
                        print(f"No data returned for keyword '{keyword}' from DBLP")
                    return
                data = await response.json()
                for entry in data.get('result', {}).get('hits', {}).get('hit', []):
                    info = entry.get('info', {})
                    year = int(info.get('year', 0))
                    title = info.get('title', '')
                    title_lower = title.lower().strip('{}').removesuffix('.')
                    # Skip if title already seen, too old, or similar to existing titles
                    if title_lower in titles_seen or any(is_similar(title_lower, existing_title) for existing_title in existing_titles):
                        continue
                    if current_year - year <= years:
                        authors = info.get('authors', {}).get('author', [])
                        # Extract author names and filter out digits
                        if isinstance(authors, list):
                            author_names = ' and '.join([''.join(filter(lambda x: not x.isdigit(), a.get('text', ''))) for a in authors])
                        else:
                            author_names = ''.join(filter(lambda x: not x.isdigit(), authors.get('text', 'N/A')))
                        # Consider only computer science or math articles
                        if 'cs' in info.get('type', '').lower() or 'math' in info.get('type', '').lower():
                            article = {
                                'id': info.get('key', 'N/A'),
                                'title': title,
                                'author': author_names,
                                'journal': 'DBLP',
                                'year': str(year),
                                'url': info.get('url', 'N/A')
                            }
                            if 'doi' in info:
                                article['doi'] = info['doi']
                            articles.append(article)
                            titles_seen.add(title_lower)
                            if use_cache:
                                save_titles_to_cache(titles_seen, cache_file='cache.json', verbose=verbose)
    except Exception as e:
        if verbose:
            print(f"An error occurred while fetching articles for keyword '{keyword}' from DBLP: {e}")

# Fetch articles from DBLP based on keywords and filter by existing titles and years
async def async_fetch_dblp_articles(keywords, existing_titles, years, limit=20, verbose=False, use_cache=False, max_concurrent_tasks=5):
    """
    Fetch articles from DBLP based on keywords, filtering by existing titles and years.

    Args:
        keywords (list): List of keywords to search for.
        existing_titles (set): Set of existing article titles to filter out.
        years (int): Number of years back to search for articles.
        limit (int, optional): Maximum number of articles to fetch per keyword. Defaults to 20.
        verbose (bool, optional): If True, print additional logs. Defaults to False.
        use_cache (bool, optional): If True, save found titles to cache. Defaults to False.
        max_concurrent_tasks (int, optional): Maximum number of concurrent tasks. Defaults to 5.

    Returns:
        list: A list of articles with details such as id, title, author, journal, year, url, and doi.
    """
    print("Fetching articles from DBLP...")
    base_url = "https://dblp.org/search/publ/api?q={}&h={}&format=json"
    articles = []
    titles_seen = set()
    current_year = datetime.now().year

    async def fetch_keyword(keyword):
        await async_fetch_dblp_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose, use_cache)

    semaphore = asyncio.Semaphore(max_concurrent_tasks)
    
    async def sem_fetch_keyword(keyword):
        async with semaphore:
            await fetch_keyword(keyword)

    tasks = [sem_fetch_keyword(keyword) for keyword in keywords]
    await asyncio.gather(*tasks)

    return articles

# Fetch and process articles for a specific keyword from Semantic Scholar
async def async_fetch_semantic_scholar_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose=False, use_cache=False):
    """
    Fetch and process articles for a specific keyword from Semantic Scholar.

    Args:
        keyword (str): The keyword to search for in Semantic Scholar.
        base_url (str): The base URL for the Semantic Scholar API.
        limit (int): Maximum number of articles to fetch per keyword.
        existing_titles (set): Set of existing article titles to filter out.
        titles_seen (set): Set of titles already seen in the current fetch.
        current_year (int): The current year.
        years (int): Number of years back to search for articles.
        articles (list): List to store fetched articles.
        verbose (bool): If True, print additional logs. Defaults to False.
        use_cache (bool, optional): If True, save found titles to cache. Defaults to False.
    """
    try:
        if verbose:
            print(f"Processing keyword '{keyword}' in Semantic Scholar")
        # Send request to Semantic Scholar API
        async with aiohttp.ClientSession() as session:
            async with session.get(base_url.format(keyword.lower().replace(" ", "+"), limit)) as response:
                data = await response.json()
                for entry in data.get('data', []):
                    year = int(entry.get('year', 0))
                    title = entry.get('title', '')
                    title_lower = title.lower().strip('{}')
                    # Skip if title already seen, too old, or similar to existing titles
                    if title_lower in titles_seen or any(is_similar(title_lower, existing_title) for existing_title in existing_titles):
                        continue
                    if current_year - year <= years:
                        authors = entry.get('authors', [])
                        author_names = ' and '.join([a.get('name', 'N/A') for a in authors])
                        fields_of_study = entry.get('fieldsOfStudy', [])
                        # Consider articles in computer science or mathematics
                        if 'Computer Science' in fields_of_study or 'Mathematics' in fields_of_study:
                            article = {
                                'id': entry.get('paperId', 'N/A'),
                                'title': title,
                                'author': author_names,
                                'journal': 'Semantic Scholar',
                                'year': str(year),
                                'url': entry.get('url', 'N/A')
                            }
                            if 'doi' in entry:
                                article['doi'] = entry['doi']
                            articles.append(article)
                            titles_seen.add(title_lower)
                            if use_cache:
                                save_titles_to_cache(titles_seen, cache_file='cache.json', verbose=verbose)
    except Exception as e:
        if verbose:
            print(f"An error occurred while fetching articles for keyword '{keyword}' from Semantic Scholar: {e}")

# Fetch articles from Semantic Scholar based on keywords and filter by existing titles and years
async def async_fetch_semantic_scholar_articles(keywords, existing_titles, years, limit=20, verbose=False, use_cache=False, max_concurrent_tasks=5):
    """
    Fetch articles from Semantic Scholar based on keywords, filtering by existing titles and years.

    Args:
        keywords (list): List of keywords to search for.
        existing_titles (set): Set of existing article titles to filter out.
        years (int): Number of years back to search for articles.
        limit (int, optional): Maximum number of articles to fetch per keyword. Defaults to 20.
        verbose (bool, optional): If True, print additional logs. Defaults to False.
        use_cache (bool, optional): If True, save found titles to cache. Defaults to False.
        max_concurrent_tasks (int, optional): Maximum number of concurrent tasks. Defaults to 5.

    Returns:
        list: A list of articles with details such as id, title, author, journal, year, url, and doi.
    """
    print("Fetching articles from Semantic Scholar...")
    base_url = "https://api.semanticscholar.org/graph/v1/paper/search/bulk?query={}&limit={}"
    articles = []  # List to store articles
    titles_seen = set()  # Set to track seen titles
    current_year = datetime.now().year  # Current year for filtering

    async def fetch_keyword(keyword):
        await async_fetch_semantic_scholar_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose, use_cache)

    semaphore = asyncio.Semaphore(max_concurrent_tasks)
    
    async def sem_fetch_keyword(keyword):
        async with semaphore:
            await fetch_keyword(keyword)

    tasks = [sem_fetch_keyword(keyword) for keyword in keywords]
    await asyncio.gather(*tasks)

    return articles

# Fetch and process articles for a specific keyword from Google Scholar
async def async_fetch_google_scholar_keyword(keyword, limit, existing_titles, titles_seen, current_year, years, articles, verbose=False, use_cache=False):
    """
    Fetch and process articles for a specific keyword from Google Scholar.

    Args:
        keyword (str): The keyword to search for in Google Scholar.
        limit (int): Maximum number of articles to fetch per keyword.
        existing_titles (set): Set of existing article titles to filter out.
        titles_seen (set): Set of titles already seen in the current fetch.
        current_year (int): The current year.
        years (int): Number of years back to search for articles.
        articles (list): List to store fetched articles.
        verbose (bool): If True, print additional logs. Defaults to False.
        use_cache (bool, optional): If True, save found titles to cache. Defaults to False.
    """
    if verbose:
        print(f"Processing keyword '{keyword}' in Google Scholar")
    try:
        search_query = scholarly.search_pubs(keyword)
        for j, entry in enumerate(search_query):
            if j >= limit:
                break
            bib = entry.get('bib', {})
            year = int(entry.get('pub_year', 0))
            title = bib.get('title', '').lower().strip('{}')
            if title in titles_seen or any(is_similar(title, existing_title) for existing_title in existing_titles) or current_year - year > years:
                continue
            article = {
                'id': entry.get('pub_url', 'N/A').split('/')[-1],
                'title': bib['title'],
                'author': ' and '.join(bib.get('author', [])),
                'journal': entry.get('venue', 'Google Scholar'),
                'year': str(year),
                'url': entry.get('pub_url', 'N/A')
            }
            if 'doi' in entry:
                article['doi'] = entry['doi']
            articles.append(article)
            titles_seen.add(title)
            if use_cache:
                save_titles_to_cache(titles_seen, cache_file='cache.json', verbose=verbose)
    except Exception as e:
        if verbose:
            print(f"An error occurred while fetching articles for keyword '{keyword}' from Google Scholar: {e}")

# Fetch articles from Google Scholar based on keywords and filter by existing titles and years
async def async_fetch_google_scholar_articles(keywords, existing_titles, years, limit=20, verbose=False, use_cache=False, max_concurrent_tasks=5):
    """
    Fetch articles from Google Scholar based on keywords and filter by existing titles and years.

    Args:
        keywords (list): List of keywords to search for.
        existing_titles (set): Set of existing article titles to filter out.
        years (int): Number of years back to search for articles.
        limit (int, optional): Maximum number of articles to fetch per keyword. Defaults to 20.
        verbose (bool, optional): If True, print additional logs. Defaults to False.
        use_cache (bool, optional): If True, save found titles to cache. Defaults to False.
        max_concurrent_tasks (int, optional): Maximum number of concurrent tasks. Defaults to 5.

    Returns:
        list: A list of articles with details such as id, title, author, journal, year, url, and doi.
    """
    print("Fetching articles from Google Scholar...")
    articles = []
    titles_seen = set()
    current_year = datetime.now().year

    async def fetch_keyword(keyword):
        await async_fetch_google_scholar_keyword(keyword, limit, existing_titles, titles_seen, current_year, years, articles, verbose, use_cache)

    semaphore = asyncio.Semaphore(max_concurrent_tasks)
    
    async def sem_fetch_keyword(keyword):
        async with semaphore:
            await fetch_keyword(keyword)

    tasks = [sem_fetch_keyword(keyword) for keyword in keywords]
    await asyncio.gather(*tasks)

    return articles

# Fetch and process articles for a specific keyword from zbMATH
async def async_fetch_zbmath_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose=False, use_cache=False):
    """
    Fetch and process articles for a specific keyword from zbMATH.

    Args:
        keyword (str): The keyword to search for in zbMATH.
        base_url (str): The base URL for the zbMATH API.
        limit (int): Maximum number of articles to fetch per keyword.
        existing_titles (set): Set of existing article titles to filter out.
        titles_seen (set): Set of titles already seen in the current fetch.
        current_year (int): The current year.
        years (int): Number of years back to search for articles.
        articles (list): List to store fetched articles.
        verbose (bool): If True, print additional logs. Defaults to False.
        use_cache (bool, optional): If True, save found titles to cache. Defaults to False.
    """
    try:
        if verbose:
            print(f"Processing keyword '{keyword}' in zbMATH")
        # Send request to zbMATH API
        async with aiohttp.ClientSession() as session:
            async with session.get(base_url.format(keyword.lower().replace(" ", "+"), limit)) as response:
                data = await response.json()
                results = data.get('result', [])
                if results is None:
                    if verbose:
                        print(f"No results found for keyword '{keyword}' in zbMATH")
                    return
                for entry in results:
                    year = int(entry.get('year', 0))
                    title = entry.get('title', {}).get('title', 'N/A')
                    title_lower = title.lower().strip('{}')
                    # Skip if title already seen, too old, or similar to existing titles
                    if title_lower in titles_seen or any(is_similar(title_lower, existing_title) for existing_title in existing_titles):
                        continue
                    if current_year - year <= years:
                        authors = entry.get('contributors', {}).get('authors', [])
                        if not authors:
                            authors = []
                        author_names = ' and '.join([a.get('name', 'N/A') for a in authors])
                        doi = next((link.get('identifier') for link in entry.get('links', []) if link.get('type') == "doi"), None)
                        article = {
                            'id': str(entry.get('id', 'N/A')),
                            'title': title,
                            'author': author_names,
                            'journal': 'zbMATH',
                            'year': str(year),
                            'url': f"https://zbmath.org/?q=an:{entry.get('id', 'N/A')}"
                        }
                        if doi:
                            article['doi'] = doi
                        articles.append(article)
                        titles_seen.add(title_lower)
                        if use_cache:
                            save_titles_to_cache(titles_seen, cache_file='cache.json', verbose=verbose)
    except Exception as e:
        if verbose:
            print(f"An error occurred while fetching articles for keyword '{keyword}' from zbMATH: {e}")

# Fetch articles from zbMATH based on keywords and filter by existing titles and years
async def async_fetch_zbmath_articles(keywords, existing_titles, years, limit=20, verbose=False, use_cache=False, max_concurrent_tasks=5):
    """
    Fetch articles from zbMATH based on keywords and filter by existing titles and years.

    Args:
        keywords (list): List of keywords to search for.
        existing_titles (set): Set of existing article titles to filter out.
        years (int): Number of years back to search for articles.
        limit (int, optional): Maximum number of articles to fetch per keyword. Defaults to 20.
        verbose (bool, optional): If True, print additional logs. Defaults to False.
        use_cache (bool, optional): If True, save found titles to cache. Defaults to False.
        max_concurrent_tasks (int, optional): Maximum number of concurrent tasks. Defaults to 5.

    Returns:
        list: A list of articles with details such as id, title, author, journal, year, url, and doi.
    """
    print("Fetching articles from zbMATH...")
    base_url = "https://api.zbmath.org/v1/document/_search?search_string={}&page=0&results_per_page={}&sort=year:desc"
    articles = []
    titles_seen = set()
    current_year = datetime.now().year

    async def fetch_keyword(keyword):
        await async_fetch_zbmath_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose, use_cache)

    semaphore = asyncio.Semaphore(max_concurrent_tasks)
    
    async def sem_fetch_keyword(keyword):
        async with semaphore:
            await fetch_keyword(keyword)

    tasks = [sem_fetch_keyword(keyword) for keyword in keywords]
    await asyncio.gather(*tasks)

    return articles

# Fetch and process articles for a specific keyword from CrossRef using crossrefapi
async def async_fetch_crossref_keyword(keyword, limit, existing_titles, titles_seen, current_year, years, articles, verbose=False, use_cache=False):
    """
    Fetch and process articles for a specific keyword from CrossRef using crossrefapi.

    Args:
        keyword (str): The keyword to search for in CrossRef.
        limit (int): Maximum number of articles to fetch per keyword.
        existing_titles (set): Set of existing article titles to filter out.
        titles_seen (set): Set of titles already seen in the current fetch.
        current_year (int): The current year.
        years (int): Number of years back to search for articles.
        articles (list): List to store fetched articles.
        verbose (bool): If True, print additional logs. Defaults to False.
        use_cache (bool, optional): If True, save found titles to cache. Defaults to False.
    """
    try:
        if verbose:
            print(f"Processing keyword '{keyword}' in CrossRef")
        
        works = Works()
        results = works.query(keyword).sort("relevance").sample(limit).all({})
        if not results:
            if verbose:
                print(f"No results found for keyword '{keyword}' in CrossRef")
            return
        
        for entry in results:
            year = entry.get('published-print', {}).get('date-parts', [[0]])[0][0]
            title = entry.get('title', [''])[0]
            title_lower = title.lower().strip('{}')
            # Skip if title already seen, too old, or similar to existing titles
            if title_lower in titles_seen or any(is_similar(title_lower, existing_title) for existing_title in existing_titles):
                continue
            if current_year - year <= years:
                authors = entry.get('author', [])
                author_names = ' and '.join([f"{a.get('given', '')} {a.get('family', '')}".strip() for a in authors])
                article = {
                    'id': entry.get('DOI', 'N/A'),
                    'title': title,
                    'author': author_names,
                    'journal': entry.get('container-title', ['CrossRef'])[0],
                    'year': str(year),
                    'url': entry.get('URL', 'N/A')
                }
                if 'DOI' in entry:
                    article['doi'] = entry['DOI']
                articles.append(article)
                titles_seen.add(title_lower)
                if use_cache:
                    save_titles_to_cache(titles_seen, cache_file='cache.json', verbose=verbose)
    except Exception as e:
        if verbose:
            print(f"An error occurred while fetching articles for keyword '{keyword}' from CrossRef: {e}")

# Fetch articles from CrossRef based on keywords and filter by existing titles and years
async def async_fetch_crossref_articles(keywords, existing_titles, years, limit=20, verbose=False, use_cache=False, max_concurrent_tasks=5):
    """
    Fetch articles from CrossRef based on keywords, filtering by existing titles and years.

    Args:
        keywords (list): List of keywords to search for.
        existing_titles (set): Set of existing article titles to filter out.
        years (int): Number of years back to search for articles.
        limit (int, optional): Maximum number of articles to fetch per keyword. Defaults to 20.
        verbose (bool, optional): If True, print additional logs. Defaults to False.
        use_cache (bool, optional): If True, save found titles to cache. Defaults to False.
        max_concurrent_tasks (int, optional): Maximum number of concurrent tasks. Defaults to 5.

    Returns:
        list: A list of articles with details such as id, title, author, journal, year, url, and doi.
    """
    print("Fetching articles from CrossRef...")
    articles = []
    titles_seen = set()
    current_year = datetime.now().year

    async def fetch_keyword(keyword):
        await async_fetch_crossref_keyword(keyword, limit, existing_titles, titles_seen, current_year, years, articles, verbose, use_cache)

    semaphore = asyncio.Semaphore(max_concurrent_tasks)
    
    async def sem_fetch_keyword(keyword):
        async with semaphore:
            await fetch_keyword(keyword)

    tasks = [sem_fetch_keyword(keyword) for keyword in keywords]
    await asyncio.gather(*tasks)

    return articles

# Function to fetch articles from all specified databases
async def async_fetch_all_articles(selected_keywords, existing_titles, years, databases, limit, verbose=False, use_cache=False, max_concurrent_tasks=5):
    """
    Fetch articles from all specified databases concurrently.

    Args:
        selected_keywords (list): List of keywords to search for.
        existing_titles (set): Set of existing article titles to filter out.
        years (int): Number of years back to search for articles.
        databases (list): List of databases to search in.
        limit (int): Maximum number of articles to fetch per keyword.
        verbose (bool, optional): If True, print additional logs. Defaults to False.
        use_cache (bool, optional): If True, save found titles to cache. Defaults to False.
        max_concurrent_tasks (int, optional): Maximum number of concurrent tasks. Defaults to 5.

    Returns:
        list: A combined list of articles fetched from all specified databases.
    """
    all_articles = []

    async def fetch_and_extend(fetch_function, *args):
        articles = await fetch_function(*args)
        all_articles.extend(articles)

    semaphore = asyncio.Semaphore(max_concurrent_tasks)
    
    async def sem_fetch_and_extend(fetch_function, *args):
        async with semaphore:
            await fetch_and_extend(fetch_function, *args)

    tasks = []

    # Create tasks for fetching articles from specified databases
    if 'arXiv' in databases:
        if await async_test_database_connection('arXiv', verbose=verbose):
            tasks.append(sem_fetch_and_extend(async_fetch_arxiv_articles, selected_keywords, existing_titles, years, limit, verbose, use_cache))
    if 'DBLP' in databases:
        if await async_test_database_connection('DBLP', verbose=verbose):
            tasks.append(sem_fetch_and_extend(async_fetch_dblp_articles, selected_keywords, existing_titles, years, limit, verbose, use_cache))
    if 'Semantic Scholar' in databases:
        if await async_test_database_connection('Semantic Scholar', verbose=verbose):
            tasks.append(sem_fetch_and_extend(async_fetch_semantic_scholar_articles, selected_keywords, existing_titles, years, limit, verbose, use_cache))
    if 'Google Scholar' in databases:
        if await async_test_database_connection('Google Scholar', verbose=verbose):
            tasks.append(sem_fetch_and_extend(async_fetch_google_scholar_articles, selected_keywords, existing_titles, years, limit, verbose, use_cache))
    if 'zbMATH' in databases:
        if await async_test_database_connection('zbMATH', verbose=verbose):
            tasks.append(sem_fetch_and_extend(async_fetch_zbmath_articles, selected_keywords, existing_titles, years, limit, verbose, use_cache))
    if 'CrossRef' in databases:
        if await async_test_database_connection('CrossRef', verbose=verbose):
            tasks.append(sem_fetch_and_extend(async_fetch_crossref_articles, selected_keywords, existing_titles, years, limit, verbose, use_cache))

    await asyncio.gather(*tasks)

    return all_articles
