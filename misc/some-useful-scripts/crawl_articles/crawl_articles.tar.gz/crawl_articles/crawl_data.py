# Last Modified: 2025-01-08
# -*- coding: utf-8 -*-

# This module provides functions to fetch and process academic articles from various online databases such as arXiv, DBLP, Semantic Scholar, Google Scholar, zbMATH, and CrossRef. The articles are fetched based on specified keywords, filtered by existing titles, and limited to a certain number of years back.
# Functions:
#     fetch_existing_titles(sources):
#         Fetch existing article titles from a list of data sources.
#     fetch_arxiv_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose):
#         Fetch and process articles for a specific keyword from arXiv.
#     fetch_arxiv_articles(keywords, existing_titles, years, limit=20, verbose=False):
#         Fetch articles from arXiv based on keywords, filtering by existing titles and years.
#     fetch_dblp_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose):
#         Fetch and process articles for a specific keyword from DBLP.
#     fetch_dblp_articles(keywords, existing_titles, years, limit=20, verbose=False):
#         Fetch articles from DBLP based on keywords, filtering by existing titles and years.
#     fetch_semantic_scholar_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose):
#         Fetch and process articles for a specific keyword from Semantic Scholar.
#     fetch_semantic_scholar_articles(keywords, existing_titles, years, limit=20, verbose=False):
#         Fetch articles from Semantic Scholar based on keywords, filtering by existing titles and years.
#     fetch_google_scholar_keyword(keyword, limit, existing_titles, titles_seen, current_year, years, articles, verbose):
#         Fetch and process articles for a specific keyword from Google Scholar.
#     fetch_google_scholar_articles(keywords, existing_titles, years, limit=20, verbose=False):
#         Fetch articles from Google Scholar based on keywords, filtering by existing titles and years.
#     fetch_zbmath_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose):
#         Fetch and process articles for a specific keyword from zbMATH.
#     fetch_zbmath_articles(keywords, existing_titles, years, limit=20, verbose=False):
#         Fetch articles from zbMATH based on keywords, filtering by existing titles and years.
#     fetch_crossref_keyword(keyword, limit, existing_titles, titles_seen, current_year, years, articles, verbose):
#         Fetch and process articles for a specific keyword from CrossRef using crossrefapi.
#     fetch_crossref_articles(keywords, existing_titles, years, limit=20, verbose=False):
#         Fetch articles from CrossRef based on keywords, filtering by existing titles and years.
#     fetch_all_articles(selected_keywords, existing_titles, years, databases, limit, verbose=False):
#         Fetch articles from all specified databases concurrently.
# Dependencies:
# - os: Provides a way of using operating system dependent functionality like reading or writing to the file system.
# - requests: Allows you to send HTTP requests easily, used here for fetching data from various APIs.
# - bibtexparser: A parser for BibTeX files, used to read and write BibTeX data.
# - bs4 (BeautifulSoup): A library for parsing HTML and XML documents, used here to parse the XML responses from arXiv.
# - datetime: Supplies classes for manipulating dates and times, used here to handle date-related operations.
# - threading: Enables concurrent execution of code, used here to fetch articles from multiple sources simultaneously.
# - crossrefapi (crossref.restful.Works): A client for the CrossRef API, used to fetch metadata for academic articles.
# - scholarly: A library to query Google Scholar, used to fetch academic articles from Google Scholar.


import os
import requests
import bibtexparser
from bs4 import BeautifulSoup
from datetime import datetime
import threading
from crossref.restful import Works
from scholarly import scholarly

# Fetch existing titles from a given URL containing a BibTeX file
def fetch_existing_titles(sources):
    """
    Fetch existing article titles from a list of data sources.

    Args:
        sources (list): A list of URLs or file paths that contain BibTeX data.

    Returns:
        set: A set of lowercased article titles without surrounding braces.
    """
    print("Fetching existing titles from data sources...")
    existing_titles = set()
    for source in sources:
        try:
            local_filename = os.path.basename(source)
            if source.startswith('http'):
                # Check if a local copy of the BibTeX data exists
                if os.path.exists(local_filename):
                    # Load the BibTeX data from the local file
                    with open(local_filename, 'r', encoding='utf-8') as local_file:
                        bib_database = bibtexparser.load(local_file)
                else:
                    # Fetch the BibTeX data from the URL
                    response = requests.get(source, timeout=10)
                    response.raise_for_status()
                    bib_database = bibtexparser.loads(response.text)
                    # Save a local copy of the BibTeX data
                    with open(local_filename, 'w', encoding='utf-8') as local_file:
                        local_file.write(response.text)
            else:
                # Load the BibTeX data from a local file
                with open(source, 'r', encoding='utf-8') as bibfile:
                    bib_database = bibtexparser.load(bibfile)
            # Extract and clean titles, then add them to the set
            existing_titles.update({entry['title'].lower().strip('{}') for entry in bib_database.entries})
        except requests.exceptions.RequestException as e:
            print(f"An error occurred while fetching titles from URL '{source}': {e}")
        except Exception as e:
            print(f"An error occurred while fetching titles from source '{source}': {e}")
    return existing_titles

# Fetch and process articles for a specific keyword from arXiv
def fetch_arxiv_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose):
    """
    Fetch and process articles for a specific keyword from arXiv.

    Args:
        keyword (str): The keyword to search for in arXiv.
        base_url (str): The base URL for the arXiv API.
        limit (int): Maximum number of articles to fetch per keyword.
        existing_titles (set): Set of existing article titles to filter out.
        titles_seen (set): Set of titles already seen in the current fetch.
        current_year (int): The current year.
        years (int): Number of years back to search for articles.
        articles (list): List to store fetched articles.
        verbose (bool): If True, print additional logs.
    """
    try:
        if verbose:
            print(f"Processing keyword '{keyword}' in arXiv")
        # Send request to arXiv API
        response = requests.get(base_url.format(keyword.lower().replace(" ", "+"), limit))
        response_text = response.text
        soup = BeautifulSoup(response_text, 'xml')
        entries = soup.find_all('entry')
        for entry in entries:
            year = int(entry.published.text[:4])
            title = entry.title.text
            title_lower = title.lower().strip('{}')
            # Skip if title already seen or too old
            if title_lower in existing_titles or title_lower in titles_seen:
                continue
            if current_year - year <= years:
                # Compile article information
                article = {
                    'id': entry.id.text.split('/')[-1],
                    'title': title,
                    'author': ' and '.join([author.find('name').text for author in entry.find_all('author')]),
                    'journal': 'arXiv preprint',
                    'year': str(year),
                    'url': entry.id.text
                }
                # Check for DOI
                doi_tag = entry.find('arxiv:doi', {'xmlns:arxiv': 'http://arxiv.org/schemas/atom'})
                if doi_tag:
                    article['doi'] = doi_tag.text
                articles.append(article)
                titles_seen.add(title_lower)
    except Exception as e:
        if verbose:
            print(f"An error occurred while fetching articles for keyword '{keyword}' from arXiv: {e}")
            
# Fetch articles from arXiv based on keywords and filter by existing titles and years
def fetch_arxiv_articles(keywords, existing_titles, years, limit=20, verbose=False):
    """
    Fetch articles from arXiv based on keywords, filtering by existing titles and years.

    Args:
        keywords (list): List of keywords to search for.
        existing_titles (set): Set of existing article titles to filter out.
        years (int): Number of years back to search for articles.
        limit (int, optional): Maximum number of articles to fetch per keyword. Defaults to 20.
        verbose (bool, optional): If True, print additional logs. Defaults to False.

    Returns:
        list: A list of articles with details such as id, title, author, journal, year, url, and doi.
    """
    print("Fetching articles from arXiv...")
    base_url = "http://export.arxiv.org/api/query?search_query=all:{}&start=0&max_results={}"
    articles = []
    titles_seen = set()
    current_year = datetime.now().year

    def fetch_keyword(keyword):
        fetch_arxiv_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose)

    threads = []
    for keyword in keywords:
        thread = threading.Thread(target=fetch_keyword, args=(keyword,))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    return articles

# Fetch and process articles for a specific keyword from DBLP
def fetch_dblp_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose):
    """
    Fetch and process articles for a specific keyword from DBLP.

    Args:
        keyword (str): The keyword to search for in DBLP.
        base_url (str): The base URL for the DBLP API.
        limit (int): Maximum number of articles to fetch per keyword.
        existing_titles (set): Set of existing article titles to filter out.
        titles_seen (set): Set of titles already seen in the current fetch.
        current_year (int): The current year.
        years (int): Number of years back to search for articles.
        articles (list): List to store fetched articles.
        verbose (bool): If True, print additional logs.
    """
    try:
        if verbose:
            print(f"Processing keyword '{keyword}' in DBLP")
        # Send request to DBLP API
        response = requests.get(base_url.format(keyword.lower().replace(" ", "+"), limit))
        data = response.json()
        for entry in data.get('result', {}).get('hits', {}).get('hit', []):
            info = entry.get('info', {})
            year = int(info.get('year', 0))
            title = info.get('title', '')
            title_lower = title.lower().strip('{}').removesuffix('.')
            # Skip if title already seen or too old
            if title_lower in existing_titles or title_lower in titles_seen:
                continue
            if current_year - year <= years:
                authors = info.get('authors', {}).get('author', [])
                # Extract author names and filter out digits
                if isinstance(authors, list):
                    author_names = ' and '.join([''.join(filter(lambda x: not x.isdigit(), a.get('text', ''))) for a in authors])
                else:
                    author_names = ''.join(filter(lambda x: not x.isdigit(), authors.get('text', 'N/A')))
                # Consider only computer science or math articles
                if 'cs' in info.get('type', '').lower() or 'math' in info.get('type', '').lower():
                    article = {
                        'id': info.get('key', 'N/A'),
                        'title': title,
                        'author': author_names,
                        'journal': 'DBLP',
                        'year': str(year),
                        'url': info.get('url', 'N/A')
                    }
                    if 'doi' in info:
                        article['doi'] = info['doi']
                    articles.append(article)
                    titles_seen.add(title_lower)
    except Exception as e:
        if verbose:
            print(f"An error occurred while fetching articles for keyword '{keyword}' from DBLP: {e}")

# Fetch articles from DBLP based on keywords and filter by existing titles and years
def fetch_dblp_articles(keywords, existing_titles, years, limit=20, verbose=False):
    """
    Fetch articles from DBLP based on keywords, filtering by existing titles and years.

    Args:
        keywords (list): List of keywords to search for.
        existing_titles (set): Set of existing article titles to filter out.
        years (int): Number of years back to search for articles.
        limit (int, optional): Maximum number of articles to fetch per keyword. Defaults to 20.
        verbose (bool, optional): If True, print additional logs. Defaults to False.

    Returns:
        list: A list of articles with details such as id, title, author, journal, year, url, and doi.
    """
    print("Fetching articles from DBLP...")
    base_url = "https://dblp.org/search/publ/api?q={}&h={}&format=json"
    articles = []
    titles_seen = set()
    current_year = datetime.now().year

    def fetch_keyword(keyword):
        fetch_dblp_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose)

    threads = []
    for keyword in keywords:
        thread = threading.Thread(target=fetch_keyword, args=(keyword,))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    return articles

# Fetch and process articles for a specific keyword from Semantic Scholar
def fetch_semantic_scholar_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose):
    """
    Fetch and process articles for a specific keyword from Semantic Scholar.

    Args:
        keyword (str): The keyword to search for in Semantic Scholar.
        base_url (str): The base URL for the Semantic Scholar API.
        limit (int): Maximum number of articles to fetch per keyword.
        existing_titles (set): Set of existing article titles to filter out.
        titles_seen (set): Set of titles already seen in the current fetch.
        current_year (int): The current year.
        years (int): Number of years back to search for articles.
        articles (list): List to store fetched articles.
        verbose (bool): If True, print additional logs.
    """
    try:
        if verbose:
            print(f"Processing keyword '{keyword}' in Semantic Scholar")
        # Send request to Semantic Scholar API
        response = requests.get(base_url.format(keyword.lower().replace(" ", "+"), limit))
        data = response.json()
        for entry in data.get('data', []):
            year = int(entry.get('year', 0))
            title = entry.get('title', '')
            title_lower = title.lower().strip('{}')
            # Skip if title already seen or too old
            if title_lower in existing_titles or title_lower in titles_seen:
                continue
            if current_year - year <= years:
                authors = entry.get('authors', [])
                author_names = ' and '.join([a.get('name', 'N/A') for a in authors])
                fields_of_study = entry.get('fieldsOfStudy', [])
                # Consider articles in computer science or mathematics
                if 'Computer Science' in fields_of_study or 'Mathematics' in fields_of_study:
                    article = {
                        'id': entry.get('paperId', 'N/A'),
                        'title': title,
                        'author': author_names,
                        'journal': 'Semantic Scholar',
                        'year': str(year),
                        'url': entry.get('url', 'N/A')
                    }
                    if 'doi' in entry:
                        article['doi'] = entry['doi']
                    articles.append(article)
                    titles_seen.add(title_lower)
    except Exception as e:
        if verbose:
            print(f"An error occurred while fetching articles for keyword '{keyword}' from Semantic Scholar: {e}")

# Fetch articles from Semantic Scholar based on keywords and filter by existing titles and years
def fetch_semantic_scholar_articles(keywords, existing_titles, years, limit=20, verbose=False):
    """
    Fetch articles from Semantic Scholar based on keywords, filtering by existing titles and years.

    Args:
        keywords (list): List of keywords to search for.
        existing_titles (set): Set of existing article titles to filter out.
        years (int): Number of years back to search for articles.
        limit (int, optional): Maximum number of articles to fetch per keyword. Defaults to 20.
        verbose (bool, optional): If True, print additional logs. Defaults to False.

    Returns:
        list: A list of articles with details such as id, title, author, journal, year, url, and doi.
    """
    print("Fetching articles from Semantic Scholar...")
    base_url = "https://api.semanticscholar.org/graph/v1/paper/search/bulk?query={}&limit={}"
    articles = []  # List to store articles
    titles_seen = set()  # Set to track seen titles
    current_year = datetime.now().year  # Current year for filtering

    def fetch_keyword(keyword):
        fetch_semantic_scholar_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose)

    threads = []
    for keyword in keywords:
        thread = threading.Thread(target=fetch_keyword, args=(keyword,))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    return articles

# Fetch and process articles for a specific keyword from Google Scholar
def fetch_google_scholar_keyword(keyword, limit, existing_titles, titles_seen, current_year, years, articles, verbose):
    """
    Fetch and process articles for a specific keyword from Google Scholar.

    Args:
        keyword (str): The keyword to search for in Google Scholar.
        limit (int): Maximum number of articles to fetch per keyword.
        existing_titles (set): Set of existing article titles to filter out.
        titles_seen (set): Set of titles already seen in the current fetch.
        current_year (int): The current year.
        years (int): Number of years back to search for articles.
        articles (list): List to store fetched articles.
        verbose (bool): If True, print additional logs.
    """
    if verbose:
        print(f"Processing keyword '{keyword}' in Google Scholar")
    try:
        search_query = scholarly.search_pubs(keyword)
        for j, entry in enumerate(search_query):
            if j >= limit:
                break
            bib = entry.get('bib', {})
            year = int(entry.get('pub_year', 0))
            title = bib.get('title', '').lower().strip('{}')
            if not title or title in existing_titles or title in titles_seen or current_year - year > years:
                continue
            article = {
                'id': entry.get('pub_url', 'N/A').split('/')[-1],
                'title': bib['title'],
                'author': ' and '.join(bib.get('author', [])),
                'journal': entry.get('venue', 'Google Scholar'),
                'year': str(year),
                'url': entry.get('pub_url', 'N/A')
            }
            if 'doi' in entry:
                article['doi'] = entry['doi']
            articles.append(article)
            titles_seen.add(title)
    except Exception as e:
        if verbose:
            print(f"An error occurred while fetching articles for keyword '{keyword}' from Google Scholar: {e}")

# Fetch articles from Google Scholar based on keywords and filter by existing titles and years
def fetch_google_scholar_articles(keywords, existing_titles, years, limit=20, verbose=False):
    """
    Fetch articles from Google Scholar based on keywords and filter by existing titles and years.

    Args:
        keywords (list): List of keywords to search for.
        existing_titles (set): Set of existing article titles to filter out.
        years (int): Number of years back to search for articles.
        limit (int, optional): Maximum number of articles to fetch per keyword. Defaults to 20.
        verbose (bool, optional): If True, print additional logs. Defaults to False.

    Returns:
        list: A list of articles with details such as id, title, author, journal, year, url, and doi.
    """
    print("Fetching articles from Google Scholar...")
    articles = []
    titles_seen = set()
    current_year = datetime.now().year

    def fetch_keyword(keyword):
        fetch_google_scholar_keyword(keyword, limit, existing_titles, titles_seen, current_year, years, articles, verbose)

    threads = []
    for keyword in keywords:
        thread = threading.Thread(target=fetch_keyword, args=(keyword,))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    return articles

# Fetch and process articles for a specific keyword from zbMATH
def fetch_zbmath_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose):
    """
    Fetch and process articles for a specific keyword from zbMATH.

    Args:
        keyword (str): The keyword to search for in zbMATH.
        base_url (str): The base URL for the zbMATH API.
        limit (int): Maximum number of articles to fetch per keyword.
        existing_titles (set): Set of existing article titles to filter out.
        titles_seen (set): Set of titles already seen in the current fetch.
        current_year (int): The current year.
        years (int): Number of years back to search for articles.
        articles (list): List to store fetched articles.
        verbose (bool): If True, print additional logs.
    """
    try:
        if verbose:
            print(f"Processing keyword '{keyword}' in zbMATH")
        response = requests.get(base_url.format(keyword.lower().replace(" ", "+"), limit))
        data = response.json()
        results = data.get('result', [])
        if not results:
            if verbose:
                print(f"No results found for keyword '{keyword}' in zbMATH")
            return
        for entry in results[:limit]:
            year = int(entry.get('year', 0))
            title = entry.get('title', {}).get('title', 'N/A')
            title_lower = title.lower().strip('{}')
            if title_lower in existing_titles or title_lower in titles_seen:
                continue
            if current_year - year <= years:
                authors = [a.get('name', 'N/A') for a in entry.get('contributors', {}).get('authors', [])]
                author_names = ' and '.join(authors)
                doi = next((link.get('identifier') for link in entry.get('links', []) if link.get('type') == "doi"), None)
                article = {
                    'id': str(entry.get('id', 'N/A')),
                    'title': title,
                    'author': author_names,
                    'journal': 'zbMATH',
                    'year': str(year),
                    'url': f"https://zbmath.org/?q=an:{entry.get('id', 'N/A')}"
                }
                if doi:
                    article['doi'] = doi
                articles.append(article)
                titles_seen.add(title_lower)
    except Exception as e:
        if verbose:
            print(f"An error occurred while fetching articles for keyword '{keyword}' from zbMATH: {e}")

# Fetch articles from zbMATH based on keywords and filter by existing titles and years
def fetch_zbmath_articles(keywords, existing_titles, years, limit=20, verbose=False):
    """
    Fetch articles from zbMATH based on keywords and filter by existing titles and years.

    Args:
        keywords (list): List of keywords to search for.
        existing_titles (set): Set of existing article titles to filter out.
        years (int): Number of years back to search for articles.
        limit (int, optional): Maximum number of articles to fetch per keyword. Defaults to 20.
        verbose (bool, optional): If True, print additional logs. Defaults to False.

    Returns:
        list: A list of articles with details such as id, title, author, journal, year, url, and doi.
    """
    print("Fetching articles from zbMATH...")
    base_url = "https://api.zbmath.org/v1/document/_search?search_string={}&page=0&results_per_page={}&sort=year:desc"
    articles = []
    titles_seen = set()
    current_year = datetime.now().year

    def fetch_keyword(keyword):
        fetch_zbmath_keyword(keyword, base_url, limit, existing_titles, titles_seen, current_year, years, articles, verbose)

    threads = []
    for keyword in keywords:
        thread = threading.Thread(target=fetch_keyword, args=(keyword,))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    return articles

# Fetch and process articles for a specific keyword from CrossRef using crossrefapi
def fetch_crossref_keyword(keyword, limit, existing_titles, titles_seen, current_year, years, articles, verbose):
    """
    Fetch and process articles for a specific keyword from CrossRef using crossrefapi.

    Args:
        keyword (str): The keyword to search for in CrossRef.
        base_url (str): The base URL for the CrossRef API.
        limit (int): Maximum number of articles to fetch per keyword.
        existing_titles (set): Set of existing article titles to filter out.
        titles_seen (set): Set of titles already seen in the current fetch.
        current_year (int): The current year.
        years (int): Number of years back to search for articles.
        articles (list): List to store fetched articles.
        verbose (bool): If True, print additional logs.
    """
    try:
        if verbose:
            print(f"Processing keyword '{keyword}' in CrossRef")
        
        works = Works()
        results = works.query(keyword).sort("relevance").sample(limit)
        if not results:
            if verbose:
                print(f"No results found for keyword '{keyword}' in CrossRef")
            return
        
        for entry in results:
            year = entry.get('published-print', {}).get('date-parts', [[0]])[0][0]
            title = entry.get('title', [''])[0]
            title_lower = title.lower().strip('{}')
            # Skip if title already seen or too old
            if title_lower in existing_titles or title_lower in titles_seen:
                continue
            if current_year - year <= years:
                authors = entry.get('author', [])
                author_names = ' and '.join([f"{a.get('given', '')} {a.get('family', '')}".strip() for a in authors])
                article = {
                    'id': entry.get('DOI', 'N/A'),
                    'title': title,
                    'author': author_names,
                    'journal': entry.get('container-title', ['CrossRef'])[0],
                    'year': str(year),
                    'url': entry.get('URL', 'N/A')
                }
                if 'DOI' in entry:
                    article['doi'] = entry['DOI']
                articles.append(article)
                titles_seen.add(title_lower)
    except Exception as e:
        if verbose:
            print(f"An error occurred while fetching articles for keyword '{keyword}' from CrossRef: {e}")

# Fetch articles from CrossRef based on keywords and filter by existing titles and years
def fetch_crossref_articles(keywords, existing_titles, years, limit=20, verbose=False):
    """
    Fetch articles from CrossRef based on keywords, filtering by existing titles and years.

    Args:
        keywords (list): List of keywords to search for.
        existing_titles (set): Set of existing article titles to filter out.
        years (int): Number of years back to search for articles.
        limit (int, optional): Maximum number of articles to fetch per keyword. Defaults to 20.
        verbose (bool, optional): If True, print additional logs. Defaults to False.

    Returns:
        list: A list of articles with details such as id, title, author, journal, year, url, and doi.
    """
    print("Fetching articles from CrossRef...")
    articles = []
    titles_seen = set()
    current_year = datetime.now().year

    for keyword in keywords:
        fetch_crossref_keyword(keyword, limit, existing_titles, titles_seen, current_year, years, articles, verbose)

    return articles

# Function to fetch articles from all specified databases
def fetch_all_articles(selected_keywords, existing_titles, years, databases, limit, verbose=False):
    """
    Fetch articles from all specified databases concurrently.

    Args:
        selected_keywords (list): List of keywords to search for.
        existing_titles (set): Set of existing article titles to filter out.
        years (int): Number of years back to search for articles.
        databases (list): List of databases to search in.
        limit (int): Maximum number of articles to fetch per keyword.
        verbose (bool, optional): If True, print additional logs. Defaults to False.

    Returns:
        list: A combined list of articles fetched from all specified databases.
    """
    all_articles = []
    threads = []

    def fetch_and_extend(fetch_function, *args):
        articles = fetch_function(*args)
        all_articles.extend(articles)

    # Create threads for fetching articles from specified databases
    if 'arXiv' in databases:
        thread = threading.Thread(target=fetch_and_extend, args=(fetch_arxiv_articles, selected_keywords, existing_titles, years, limit, verbose))
        threads.append(thread)
        thread.start()
    if 'DBLP' in databases:
        thread = threading.Thread(target=fetch_and_extend, args=(fetch_dblp_articles, selected_keywords, existing_titles, years, limit, verbose))
        threads.append(thread)
        thread.start()
    if 'Semantic Scholar' in databases:
        thread = threading.Thread(target=fetch_and_extend, args=(fetch_semantic_scholar_articles, selected_keywords, existing_titles, years, limit, verbose))
        threads.append(thread)
        thread.start()
    if 'Google Scholar' in databases:
        thread = threading.Thread(target=fetch_and_extend, args=(fetch_google_scholar_articles, selected_keywords, existing_titles, years, limit, verbose))
        threads.append(thread)
        thread.start()
    if 'zbMATH' in databases:
        thread = threading.Thread(target=fetch_and_extend, args=(fetch_zbmath_articles, selected_keywords, existing_titles, years, limit, verbose))
        threads.append(thread)
        thread.start()
    if 'CrossRef' in databases:
        thread = threading.Thread(target=fetch_and_extend, args=(fetch_crossref_articles, selected_keywords, existing_titles, years, limit, verbose))
        threads.append(thread)
        thread.start()

    # Wait for all threads to finish
    for thread in threads:
        thread.join()

    return all_articles