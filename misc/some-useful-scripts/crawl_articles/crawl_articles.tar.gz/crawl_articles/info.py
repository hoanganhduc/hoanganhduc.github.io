# Last Modified: 2025-01-08
# -*- coding: utf-8 -*-

# This module provides various utility functions for an article crawler script. 
# The script fetches articles from various databases based on user-selected keywords 
# and performs several tasks such as printing environment information.
# Functions:
#     - print_welcome_message(): Print a welcome message and briefly explain what the script does.
#     - print_environment_info(start_time, verbose=False): Print environment and resource usage information.
#     - enable_debug_mode(): Enable debug mode to print all outputs and error messages to a txt file.
#     - handle_print_default_keywords(): Print default keywords if the corresponding argument is provided.
#
# Dependencies:
#     - os: For interacting with the operating system.
#     - sys: For accessing system-specific parameters and functions.
#     - time: For time-related functions.
#     - psutil: For retrieving information on system utilization (CPU, memory, disks, network, sensors).
#     - .output: For printing keywords in columns.
#     - .setting: For accessing default keywords.

import os
import sys
import time
import psutil
from .output import print_keywords_in_columns
from .setting import default_keywords

# Function to print a welcome message and briefly explain what the script does
def print_welcome_message():
    """
    Print a welcome message and briefly explain what the script does.
    """
    print("Welcome to the Article Crawler Script!")
    print("This script fetches articles from various databases based on user-selected keywords.")
    print("You can specify keywords, the number of years back to search, and the databases to search within.")
    print("The available databases are: arXiv, DBLP, Semantic Scholar, Google Scholar, zbMATH, and CrossRef.")
    print("The script will filter out existing articles fetched from known data sources and save the new articles in the specified format (BibTeX, HTML, PDF, or all).")
    print("You can also clean up generated files, enable debug mode for detailed logs, and upload generated files to multiple services.")
    print("Supported upload services: Dropbox (using rclone), temp.sh, and bashupload.com.")
    print("Let's get started!\n")

# Function to print environment and resource usage information
def print_environment_info(start_time, verbose=False):
    """
    Print environment and resource usage information.

    Args:
        start_time (float): The start time of the script.
        verbose (bool): If True, print detailed environment and resource usage information.

    This function prints the elapsed time of the script. If verbose is True, it also prints
    detailed resource usage information such as CPU time, memory usage, number of threads,
    disk usage, network I/O, operating system details, and Python version.
    """
    end_time = time.time()
    elapsed_time = end_time - start_time
    
    if verbose:
        # Gather process and system information
        process = psutil.Process(os.getpid())
        memory_info = process.memory_info()
        cpu_usage = psutil.cpu_percent(interval=1)
        python_version = sys.version
        num_threads = process.num_threads()
        disk_usage = psutil.disk_usage('/')
        net_io = psutil.net_io_counters()

        # Get CPU times
        user_time, system_time, children_user_time, children_system_time = os.times()[:4]

        # Print detailed environment and resource usage information
        print("\nEnvironment and Resource Usage Information:")
        print(f"Elapsed Time: {elapsed_time:.2f} seconds")
        print(f"User CPU Time: {user_time:.2f} seconds")
        print(f"System CPU Time: {system_time:.2f} seconds")
        print(f"Children User CPU Time: {children_user_time:.2f} seconds")
        print(f"Children System CPU Time: {children_system_time:.2f} seconds")
        print(f"CPU Usage: {cpu_usage}%")
        print(f"Memory Usage: {memory_info.rss / (1024 * 1024):.2f} MB")
        print(f"Number of Threads: {num_threads}")
        print(f"Disk Usage: {disk_usage.percent}% used")
        print(f"Network I/O: Sent = {net_io.bytes_sent / (1024 * 1024):.2f} MB, Received = {net_io.bytes_recv / (1024 * 1024):.2f} MB")
        
        # Print OS-specific information
        if os.name == 'posix':
            os_info = os.uname()
            print(f"Operating System: {os_info.sysname} {os_info.release} {os_info.version}")
        elif os.name == 'nt':
            print(f"Operating System: Windows {os.sys.getwindowsversion().major}.{os.sys.getwindowsversion().minor}")
        
        print(f"Python Version: {python_version}")
    else:
        # Print only the total elapsed time of the script
        print(f"Elapsed Time: {elapsed_time:.2f} seconds")
    
def enable_debug_mode():
    """
    Enable debug mode to print all outputs and error messages to a txt file.
    """
    class Tee:
        def __init__(self, *files):
            self.files = files
        def write(self, obj):
            for f in self.files:
                f.write(obj)
        def flush(self):
            for f in self.files:
                f.flush()
    log_file = open('debug_output.txt', 'w')
    sys.stdout = Tee(sys.stdout, log_file)
    sys.stderr = Tee(sys.stderr, log_file)
    
def handle_print_default_keywords():
    """
    Print default keywords if the corresponding argument is provided.
    """
    print_keywords_in_columns(default_keywords, 2)
