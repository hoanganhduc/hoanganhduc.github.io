# Last Modified: 2025-01-08
# -*- coding: utf-8 -*-

# This module provides functionality to convert a list of articles into different formats (BibTeX, HTML, PDF) and save them to files. 
# It uses threading to perform these conversions concurrently.
# Functions:
# - articles_to_bibtex(articles): Converts a list of articles into a BibTeX-formatted string.
# - articles_to_html(articles): Converts a list of articles into an HTML-formatted string.
# - write_bibtex(all_articles, timestamp, verbose=False): Writes the articles to a BibTeX file.
# - write_html(all_articles, timestamp, verbose=False): Writes the articles to an HTML file.
# - write_pdf(all_articles, timestamp, verbose=False): Writes the articles to a PDF file using ReportLab.
# - save_articles_to_files(all_articles, output_format, verbose=False, timestamp=""): Saves fetched articles to files based on the specified output format using threading.
# - print_keywords_in_columns(keywords, columns): Prints keywords in a specified number of columns for better readability.
# Dependencies:
# - os: Provides a way of using operating system dependent functionality.
# - threading: Allows for concurrent execution of code.
# - datetime: Supplies classes for manipulating dates and times.
# - jinja2: A templating engine for Python.
# - bibtexparser: A parser for BibTeX files.
# - reportlab: A library for generating PDFs.

import os
import threading
from datetime import datetime
from jinja2 import Environment, FileSystemLoader
import bibtexparser
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

# Print keywords in columns for better readability
def print_keywords_in_columns(keywords, columns):
    """
    Print the keywords in a specified number of columns for better readability.

    Args:
        keywords (list): List of keywords to be printed.
        columns (int): Number of columns to print the keywords in.
    """
    # Calculate the number of rows needed given the number of columns
    rows = (len(keywords) + columns - 1) // columns

    # Iterate over each row
    for row in range(rows):
        # Iterate over each column in the current row
        for col in range(columns):
            # Calculate the index of the keyword in the flattened list
            index = row + col * rows
            # Check if the index is within the list size
            if index < len(keywords):
                # Print the keyword with formatting
                print(f"{index + 1}. {keywords[index]:<30}", end=' ')
        # Print a newline after each row
        print()
        
# Convert articles to BibTeX format
def articles_to_bibtex(articles):
    """
    Convert a list of articles into a BibTeX database.

    :param articles: A list of dictionaries containing article details.
    :return: A BibTeX-formatted string representing the database.
    """
    try:
        # Create a new BibTeX database
        bib_database = bibtexparser.bibdatabase.BibDatabase()
        bib_database.entries = []
        for article in articles:
            # Create a new BibTeX entry from the article details
            entry = {
                'ENTRYTYPE': 'article',  # All entries are articles
                'ID': article['id'],  # Use the ID as the BibTeX key
                'title': f"{{{article['title']}}}",  # Title of the article with braces
                'author': article['author'],  # Authors of the article
                'journal': article['journal'],  # Journal or venue of the article
                'year': article['year']  # Year of publication
            }
            # Add the URL of the article
            entry['url'] = article['url']
            # If the article has a DOI, add it
            if 'doi' in article:
                entry['doi'] = article['doi']
            # If the article is an arXiv preprint, add the eprint and archivePrefix fields
            if article['journal'] == 'arXiv preprint':
                entry['eprint'] = article['id']
                entry['archivePrefix'] = 'arXiv'
            # Add the entry to the database
            bib_database.entries.append(entry)
        # Convert the database to a BibTeX-formatted string
        return bibtexparser.dumps(bib_database)
    except Exception as e:
        print(f"An error occurred while converting articles to BibTeX: {e}")
        return None

# Convert articles to HTML format
def articles_to_html(articles):
    """
    Convert a list of articles into an HTML document.

    :param articles: A list of dictionaries containing article details.
    :return: An HTML-formatted string representing the articles.
    """
    try:
        # Create a Jinja2 environment with a file system loader
        env = Environment(loader=FileSystemLoader('.'))

        # Define the default template for the HTML document
        default_template = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Reconfiguration Articles</title>
        </head>
        <body>
            <h1>Reconfiguration Articles</h1>
            <ol>
            {% for article in articles %}
                <li>
                    <strong>{{ article.title }}</strong><br>
                    Author(s): {{ article.author }}<br>
                    Journal: {{ article.journal }}<br>
                    Year: {{ article.year }}<br>
                    <a href="{{ article.url }}">Link</a>
                </li>
            {% endfor %}
            </ol>
        </body>
        </html>
        """

        # Write the default template to a temporary file called 'template.html'
        with open('template.html', 'w', encoding='utf-8') as template_file:
            template_file.write(default_template)

        # Get the Jinja2 template from the temporary file
        template = env.get_template('template.html')

        # Render the HTML document from the template and the list of articles
        html_content = template.render(articles=articles)

        # Write the rendered HTML document to a file called 'articles.html'
        with open('articles.html', 'w', encoding='utf-8') as htmlfile:
            htmlfile.write(html_content)

        # Attempt to remove the temporary 'template.html' file
        try:
            os.remove('template.html')
        except OSError as e:
            print(f"Error removing temporary template file: {e}")

        # Return the rendered HTML document
        return html_content

    except Exception as e:
        print(f"An error occurred while converting articles to HTML: {e}")
        return None
    
# Function to write articles to a BibTeX file
def write_bibtex(all_articles, timestamp, verbose=False):
    """Write the articles to a BibTeX file."""
    if verbose:
        print("Starting to write BibTeX file...")
    try:
        bibtex_data = articles_to_bibtex(all_articles)
        with open(f'articles_{timestamp}.bib', 'w', encoding='utf-8') as bibfile:
            bibfile.write(bibtex_data)
        if verbose:
            print("Finished writing BibTeX file.")
    except Exception as e:
        print(f"An error occurred while writing the BibTeX file: {e}")

# Function to write articles to an HTML file
def write_html(all_articles, timestamp, verbose=False):
    """Write the articles to an HTML file."""
    if verbose:
        print("Starting to write HTML file...")
    try:
        html_content = articles_to_html(all_articles)
        with open(f'articles_{timestamp}.html', 'w', encoding='utf-8') as htmlfile:
            htmlfile.write(html_content)
        if verbose:
            print("Finished writing HTML file.")
    except Exception as e:
        print(f"An error occurred while generating the HTML file: {e}")

# Function to write articles to a PDF file using ReportLab
def write_pdf(all_articles, timestamp, verbose=False):
    """Write the articles to a PDF file using ReportLab."""
    if verbose:
        print("Starting to write PDF file...")

    try:
        pdf_file = f'articles_{timestamp}.pdf'
        c = canvas.Canvas(pdf_file, pagesize=A4)
        width, height = A4

        # Set PDF metadata
        c.setTitle("Reconfiguration Articles")
        c.setAuthor("Article Crawler Script")
        c.setSubject("A collection of articles on reconfiguration problems")
        c.setKeywords("reconfiguration, articles, research, bibliography")

        # Set the font and title
        c.setFont('Times-Roman', 16)
        c.drawString(40, height - 40, "Reconfiguration Articles")
        c.setFont('Times-Roman', 12)

        y_position = height - 80
        line_height = 14

        def draw_wrapped_text(text, x, y, max_width):
            """Draw text with word wrapping."""
            lines = []
            words = text.split()
            while words:
                line = ''
                while words and c.stringWidth(line + words[0], 'Times-Roman', 12) < max_width:
                    line += words.pop(0) + ' '
                lines.append(line)
            for line in lines:
                c.drawString(x, y, line.strip())
                y -= line_height
            return y

        for article in all_articles:
            if y_position < 100:
                c.showPage()
                c.setFont('Times-Roman', 12)
                y_position = height - 40

            y_position = draw_wrapped_text(f"Title: {article['title']}", 40, y_position, width - 80)
            y_position -= line_height
            y_position = draw_wrapped_text(f"Author(s): {article['author']}", 40, y_position, width - 80)
            y_position -= line_height
            y_position = draw_wrapped_text(f"Journal: {article['journal']}", 40, y_position, width - 80)
            y_position -= line_height
            y_position = draw_wrapped_text(f"Year: {article['year']}", 40, y_position, width - 80)
            y_position -= line_height
            y_position = draw_wrapped_text(f"URL: {article['url']}", 40, y_position, width - 80)
            y_position -= line_height
            if 'doi' in article:
                y_position = draw_wrapped_text(f"DOI: {article['doi']}", 40, y_position, width - 80)
                y_position -= line_height
            y_position -= line_height

        c.save()

        if verbose:
            print("Finished writing PDF file.")
    except Exception as e:
        print(f"An error occurred while generating the PDF file: {e}")

# Function to save fetched articles to files based on specified output format
def save_articles_to_files(all_articles, output_format, verbose=False, timestamp=""):
    """
    Save fetched articles to files based on the specified output format.

    Args:
        all_articles (list): List of articles to be saved.
        output_format (list): The formats in which to save the articles (e.g., ['bib', 'html', 'pdf']).
        verbose (bool): If True, print additional logs.

    This function utilizes threading to write the articles in the specified formats concurrently.
    """
    if not all_articles:
        print("No articles to save.")
        return
    
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")

    # Initialize threads for writing files
    threads = []
    if 'bib' in output_format or 'all' in output_format:
        bibtex_thread = threading.Thread(target=write_bibtex, args=(all_articles, timestamp, verbose))
        threads.append(bibtex_thread)
        bibtex_thread.start()

    if 'html' in output_format or 'all' in output_format:
        html_thread = threading.Thread(target=write_html, args=(all_articles, timestamp, verbose))
        threads.append(html_thread)
        html_thread.start()

    if 'pdf' in output_format or 'all' in output_format:
        pdf_thread = threading.Thread(target=write_pdf, args=(all_articles, timestamp, verbose))
        threads.append(pdf_thread)
        pdf_thread.start()

    # Wait for all threads to finish
    for thread in threads:
        thread.join()

    # Print completion message based on the output format
    if 'html' in output_format or 'all' in output_format:
        print(f"HTML file 'articles_{timestamp}.html' has been created.")
    if 'bib' in output_format or 'all' in output_format:
        print(f"BibTeX file 'articles_{timestamp}.bib' has been created.")
    if 'pdf' in output_format or 'all' in output_format:
        print(f"PDF file 'articles_{timestamp}.pdf' has been created.")
    if not any(fmt in output_format for fmt in ['bib', 'html', 'pdf', 'all']):
        print(f"Script finished. There was an error creating the files.")