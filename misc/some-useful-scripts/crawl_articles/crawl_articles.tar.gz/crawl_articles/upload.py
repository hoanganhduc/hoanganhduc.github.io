# Last Modified: 2025-01-10
# -*- coding: utf-8 -*-

# This module provides functions to upload files to various online services including Dropbox, temp.sh, and bashupload.com.
# It uses rclone for Dropbox uploads and the requests library for HTTP POST uploads to temp.sh and bashupload.com.
# Functions:
#     upload_to_dropbox(filenames, dropbox_directory, verbose=False):
#         Uploads files to Dropbox using rclone.
#     upload_to_tempsh(filenames, verbose=False):
#         Uploads files to temp.sh.
#     upload_to_bashupload(filenames, verbose=False):
#         Uploads files to bashupload.com.
#     upload_articles(filenames, upload_service, upload_destination, verbose=False):
#         Uploads files to the specified service.
#     handle_upload_files(upload_arg, filenames, verbose):
#         Handles the upload of files to the specified service(s).

import os
import requests

# Function to upload generated files to Dropbox using rclone
def upload_to_dropbox(filenames, dropbox_directory, verbose=False):
    """
    Upload generated files to Dropbox using rclone.

    Args:
        filenames (list): List of filenames to be uploaded.
        dropbox_directory (str): The Dropbox directory to upload the files to.
        verbose (bool): If True, print additional logs.
    """
    try:
        # Check if rclone is installed
        rclone_installed = os.system('rclone --version >nul 2>&1') == 0
        if not rclone_installed:
            print("rclone is not installed. Please install rclone and set it up with Dropbox.")
            return

        # Upload each file to Dropbox using rclone
        for filename in filenames:
            if os.path.exists(filename):
                if verbose:
                    print(f"Uploading {filename} to Dropbox directory {dropbox_directory}...")
                # Check if the Dropbox directory exists, create it if it doesn't
                os.system(f'rclone mkdir dropbox:/{dropbox_directory} >nul 2>&1')
                upload_result = os.system(f'rclone copy {filename} dropbox:/{dropbox_directory}/ >nul 2>&1')
                if upload_result != 0:
                    print(f"Failed to upload {filename} to Dropbox. Please ensure Dropbox is set up correctly with rclone.")
                else:
                    print(f"Successfully uploaded {filename} to Dropbox directory {dropbox_directory}.")
                    # Write Dropbox path to upload_info.txt
                    if verbose:
                        print(f"Writing Dropbox path to upload_info.txt...")
                    with open('upload_info.txt', 'a') as info_file:
                        info_file.write(f"{filename}: dropbox:/{dropbox_directory}/{os.path.basename(filename)}\n")
            else:
                if verbose:
                    print(f"File {filename} does not exist and will not be uploaded.")

    except Exception as e:
        print(f"An error occurred while uploading files to Dropbox: {e}")

# Function to upload generated files to temp.sh
def upload_to_tempsh(filenames, verbose=False):
    """
    Upload generated files to temp.sh.

    Args:
        filenames (list): List of filenames to be uploaded.
        verbose (bool): If True, print additional logs.
    """
    try:
        # Upload each file to temp.sh
        for filename in filenames:
            if os.path.exists(filename):
                if verbose:
                    print(f"Uploading {filename} to temp.sh...")
                with open(filename, 'rb') as file:
                    response = requests.post('https://temp.sh/upload', files={'file': file})
                    if response.status_code == 200:
                        download_link = response.text.strip()
                        print(f"Successfully uploaded {filename} to temp.sh. Download link: {download_link}")
                        # Write download link to upload_info.txt
                        if verbose:
                            print(f"Writing download link to upload_info.txt...")
                        with open('upload_info.txt', 'a') as info_file:
                            info_file.write(f"{filename}: {download_link}\n")
                    else:
                        print(f"Failed to upload {filename} to temp.sh. Status code: {response.status_code}")
            else:
                if verbose:
                    print(f"File {filename} does not exist and will not be uploaded.")
    except Exception as e:
        print(f"An error occurred while uploading files to temp.sh: {e}")

# Function to upload generated files to bashupload.com
def upload_to_bashupload(filenames, verbose=False):
    """
    Upload generated files to bashupload.com.

    Args:
        filenames (list): List of filenames to be uploaded.
        verbose (bool): If True, print additional logs.
    """
    try:
        # Upload each file to bashupload.com
        for filename in filenames:
            if os.path.exists(filename):
                if verbose:
                    print(f"Uploading {filename} to bashupload.com...")
                with open(filename, 'rb') as file:
                    response = requests.post('https://bashupload.com', files={'file': file})
                    if response.status_code == 200:
                        download_link = response.text.strip()
                        print(f"Successfully uploaded {filename} to bashupload.com. Download link: {download_link}")
                        # Write download link to upload_info.txt
                        if verbose:
                            print(f"Writing download link to upload_info.txt...")
                        with open('upload_info.txt', 'a') as info_file:
                            info_file.write(f"{filename}: {download_link}\n")
                    else:
                        print(f"Failed to upload {filename} to bashupload.com. Status code: {response.status_code}")
            else:
                if verbose:
                    print(f"File {filename} does not exist and will not be uploaded.")
    except Exception as e:
        print(f"An error occurred while uploading files to bashupload.com: {e}")

# Save the fetched articles to files and upload them to the specified service
def upload_articles(filenames, upload_service, upload_destination, verbose=False):
    """
    Save fetched articles to files and upload them to the specified service.

    Args:
        filenames (list): List of filenames to be uploaded.
        upload_service (str): The service to upload the files to ('dropbox', 'tempsh', 'bashupload', or 'all').
        upload_destination (str): The destination directory or service-specific identifier for the upload.
        verbose (bool): If True, print additional logs.
    """
    # Upload files to the specified service
    if upload_service == 'dropbox':
        upload_to_dropbox(filenames, upload_destination, verbose)
    elif upload_service == 'tempsh':
        upload_to_tempsh(filenames, verbose)
    elif upload_service == 'bashupload':
        upload_to_bashupload(filenames, verbose)
    elif upload_service == 'all':
        upload_to_dropbox(filenames, upload_destination, verbose)
        upload_to_tempsh(filenames, verbose)
        upload_to_bashupload(filenames, verbose)
    else:
        print(f"Unknown upload service: {upload_service}. Supported services are 'dropbox', 'tempsh', 'bashupload', and 'all'.")
        
def handle_upload_files(upload_arg, filenames, verbose):
    """
    Upload files to the specified service if specified.

    Args:
        upload_arg (str): The upload argument specifying the services and destinations.
        filenames (list): List of filenames to be uploaded.
        verbose (bool): If True, print additional logs.
    """
    upload_services = upload_arg.split(',')
    for service in upload_services:
        if ':' in service:
            upload_service, upload_destination = service.split(':', 1)
        else:
            upload_service = service
            upload_destination = ''
        try:
            upload_articles(filenames, upload_service, upload_destination, verbose)
        except Exception as e:
            print(f"An error occurred while uploading to {upload_service}: {e}")
            continue