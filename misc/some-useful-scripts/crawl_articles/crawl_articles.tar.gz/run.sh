#!/bin/bash
# Last Modified: 2025-01-15

# Get the directory of the current script
LOCAL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Function to run the crawl script
function crawl {
    cd "$LOCAL_DIR"
    if [[ -f "crawl.py" ]]; then
        # Run the crawl.py script with specified options
        python crawl.py --default --verbose --upload tempsh --cache --async-fetch --debug
        # python crawl.py --keywords none --database 1 --years 1 --limit 20 --output-formats pdf --verbose --upload "tempsh" --cache --async-fetch
    else
        echo "Error: crawl not found in $LOCAL_DIR"
        return 1
    fi
}

# Function to clean unnecessary outputs
function clean {
    cd "$LOCAL_DIR"
    
    echo "Cleaning unnecessary outputs..."
    # Run the crawl.py script with the --clean option
    python crawl.py --clean
    
    echo "Cleanup completed."
}

# Remote server details
REMOTE_USER="username"
REMOTE_HOST="remote.server.org"
REMOTE_DIR="reconf"

# Function to update files from the remote host
function update {
    echo "Starting update from $REMOTE_HOST..."
    # Use rsync to update files from the remote host
    rsync -avz --delete "$REMOTE_USER@$REMOTE_HOST:$REMOTE_DIR/" "$LOCAL_DIR/"
    if [[ $? -ne 0 ]]; then
        echo "Error: Failed to update files from $REMOTE_HOST"
        return 1
    fi
    echo "Files updated successfully from $REMOTE_HOST"
}

# Function to sync files to the remote host
function sync {
    echo "Starting sync to $REMOTE_HOST..."
    # Use rsync to sync files to the remote host
    rsync -avz --delete "$LOCAL_DIR/" "$REMOTE_USER@$REMOTE_HOST:$REMOTE_DIR/"
    if [[ $? -ne 0 ]]; then
        echo "Error: Failed to sync files to $REMOTE_HOST"
        return 1
    fi
    echo "Files synced successfully to $REMOTE_HOST"
}

# Function to display usage information
function usage {
    echo "Usage: $0 <command>"
    echo "Available commands:"
    echo "  crawl   - Run the crawl script"
    echo "  update  - Update files from remote host"
    echo "  sync    - Sync files to remote host"
    echo "  clean   - Clean unnecessary outputs"
}

# Main function to handle command-line arguments
function main {
    if [[ $# -eq 0 ]]; then
        usage
        exit 1
    fi

    case "$1" in
        crawl)
            crawl
            ;;
        update)
            update
            ;;
        sync)
            sync
            ;;
        clean)
            clean
            ;;
        help)
            usage
            ;;
        *)
            echo "Error: Unknown command '$1'"
            echo "Available commands: crawl, update, sync, clean, help"
            exit 1
            ;;
    esac
}

# Call the main function with all command-line arguments
main "$@"
