#!/bin/bash

function run_crawl {
    local script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    cd "$script_dir"
    if [[ -f "crawl.py" ]]; then
        python crawl.py --default --verbose --upload tempsh --cache
    else
        echo "Error: crawl.py not found in $script_dir"
        return 1
    fi
}

run_crawl
