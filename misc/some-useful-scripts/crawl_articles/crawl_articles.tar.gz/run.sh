#!/bin/bash

function run_crawl {
    local script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    cd "$script_dir"
    if [[ -f "crawl.py" ]]; then
        python crawl.py --default --verbose --upload tempsh --cache --async-fetch --output-formats pdf
        # python crawl.py --keywords none --database 1 --years 1 --limit 20 --output-formats pdf --verbose --upload "tempsh" --cache --async-fetch
    else
        echo "Error: crawl not found in $script_dir"
        return 1
    fi
}

run_crawl
