InstallChoco.cmd
================

http://www.easy2boot.com/add-payload-files/windows-install-isos/sdi-choco/chocbox/

Offline install of Chocolatey.

You need to add the Chocolatey package for Chocolatey itself to this folder:

1. Run \_ISO\docs\ChocBox\ChocBox.cmd
2. Make a Chocolatey package (press ENTER for latest version)
3. Copy the C:\DRIVERS\CHOCBOX\Chocolatey*.nupkg file to USB:\_ISO\WINDOWS\INSTALLS\INSTALLCHOCO\chocolatey.nupkg


Action of Scripts
=================

InstallChoco.cmd runs installchoco.ps1
InstallChoco.ps1 installs Chocolatey.nupkg to C:\ProgramData\Chocolatey folder and adds to Path environment variable so that choco commands can be run

If Chocolatey folder already exists, then it will not be re-installed.
