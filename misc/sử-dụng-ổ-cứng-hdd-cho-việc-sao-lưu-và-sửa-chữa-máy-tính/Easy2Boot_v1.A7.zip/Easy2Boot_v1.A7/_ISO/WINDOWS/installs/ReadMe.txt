\_ISO\WINDOWS\INSTALLS using SDI_CHOCO
======================================

See http://www.easy2boot.com/add-payload-files/windows-install-isos/sdi-choco/ for the latest information.

This folder is for Vista\7\8\10 installs from a standard Microsoft ISO installer file.
Note: Use the latest Windows 10 ISOs (the first 2015 WIN10 TH2 ISOs had problems with network\internet connectivity!).

XP Installer ISOs are not supported.

An XML file must be used (e.g. ***SDI_CHOCO.XML) which contains special sections which will cause a file in the
\_ISO\WINDOWS\INSTALLS\CONFIGS folder to be run after all the Windows files have been copied to the target hard disk.

The \_ISO\WINDOWS\INSTALLS\CONFIGS folder should contain the .cmd file that is specified in the XML file.
e.g. \_ISO\WINDOWS\INSTALLS\CONFIGS\904_W10.cmd

\_ISO\WINDOWS\INSTALLS\APPS     - If you have bespoke apps (e.g. Chrome), copy the installations files to a folder here
\_ISO\WINDOWS\INSTALLS\CONFIGS  - contains the .cmd file that runs during the 'Specialize' pass + any special drivers, etc.
\_ISO\WINDOWS\INSTALLS\DRIVERS	- contains any bespoke machine-specific drivers, e.g. \_ISO\WINDOWS\INSTALLS\DRIVERS\904_W10\x86 (or amd64)
\_ISO\WINDOWS\INSTALLS\INSTALLCHOCO - used to install Chocolatey if no internet available (offline installs)
\_ISO\WINDOWS\INSTALLS\SNAPPY       - contains the Snappy Driver Installer (SDI) software and large DriverPacks
\_ISO\WINDOWS\INSTALLS\wsusoffline  - used for the WSUS Offline Updater files.


Main script files
=================

The SDI_CHOCO configuration set is provided as an example for you to copy/rename.
If you use the SDI_CHOCO configuration - do NOT change any of the existing E2B files. You can create new files but do not change existing files. This is because any E2B update that you make in future will overwrite any changed files.

Typically, there are three user .cmd scripts that run during installation (example for SDI_CHOCO config):
\_ISO\WINDOWS\INSTALLS\CONFIGS\SDI_CHOCO\MySpecialize.cmd - this runs once during the first Specialize pass (called by the SDI_CHOC.cmd config file)
\_ISO\WINDOWS\INSTALLS\CONFIGS\SDI_CHOCO\MySetupcomplete.cmd - this runs once just before first login as 'system'. There is typially no mouse pointer and the console is hidden.
\_ISO\WINDOWS\INSTALLS\CONFIGS\SDI_CHOCO\MyStartup.cmd - this runs once after first user login - it has Administrator rights.

These are the main three files that you can create and modify for the install process. Example 'Sample_Myxxxx.cmd' files are provided for you to copy.
Note that SDI_CHOCO.cmd will run whether the system is a 32-bit system or 64-bit system, so your .cmd files need to cope with both types of system.

You can install your own extra drivers using MySpecialize.cmd (if required).
You can install apps using MyStartup.cmd.

Tip: The %BIT% variable will be either 'x86' or 'amd64'.

CONFIGURATION SETS
==================

A 'configuration set' comprises of the XML file, config script + config folder:

1. XML file - this specifies what configuration script to run - e.g. \_ISO\WINDOWS\INSTALLS\CONFIGS\904_W10.cmd
2. Configuration script - this script will copy the Configuration folder and other folders to the target drive, e.g. \_ISO\WINDOWS\INSTALLS\CONFIGS\904_W10.cmd
3. Configuration folder - this folder controls what apps are added + other tweaks. It is copied to C:\DRIVERS. e.g. \_ISO\WINDOWS\INSTALLS\CONFIGS\904_W10\*.* >> C:\DRIVERS


CONFIGS Folder
==============

Under here should be a machine-specific folder for different configurations - e.g. SDI_CHOCO folder, plus a SDI_CHOCO.cmd file that is called by the XML file.
The folder can contain any special files that you want to be copied to the target hard disk.
Amongst these files should be a file called startup.cmd and setupcomplete.cmd plus various .exe files, etc.

The main config file (specified in the XML - e.g. \_ISO\WINDOWS\INSTALLS\CONFIGS\904_W10.cmd) will typically contain code to:
	Find the USB drive letter
	Copy over any apps and configuration\driver files to the hard disk
	Copy the startup.cmd and setupcomplete.cmd files (whole config folder) to \DRIVERS on the hard disk
	Run SDI to install all drivers automatically
	Run Chocolatey to install any apps (network connection required)
	Call MySpecialize.cmd
	Tidy up any files
	Enable UAC.

	If using SDI_CHOCO.cmd, you should not change this file.
	If you are using your own Configuration script, you will need to change the 'set CONFIGDIR=xxxxx' line.
	

APPS Folder
===========
The main config batch file (e.g. SDI_CHOCO.cmd) can copy the correct folders (x86/amd64/both) to C:\DRIVERS\APPS.

When startup.cmd runs at first user login, it will automatically run any .cmd file located in C:\DRIVERS\APPS folder.

Note: This is NOT anything to do with Chocolatey app installs. 
This folder is for any special apps that you want to install.

Example:
This folder should contain special application installation files - e.g. CHROME

Example: Under this (CHROME) folder, there can be 1, 2 or 3 sub-folders: e.g. 

\_ISO\WINDOWS\INSTALLS\APPS\CHROME\AMD64
\_ISO\WINDOWS\INSTALLS\APPS\CHROME\X86
\_ISO\WINDOWS\INSTALLS\APPS\CHROME\BOTH

If your install files (e.g. .exe, .msi, etc.) will install to both 32-bit and 64-bit OS's
(or if it is a 32-bit application and there is no 64-bit version) then place the application files in the BOTH folder.
Otherwise, place the 32-bit installation files in the X86 folder and the 64-bit installation files in the AMD64 folder.

Any .cmd file that is present in the folder will be called by StartUp.cmd on first user logon.
So make sure only one .cmd file is present in each folder.
All applications folders will be copied to the C:\DRIVERS\APPS\ folder, so the .cmd file must expect to be run from C:\DRIVERS\APPS.

You can download application install files from npackd.appspot.com, choose a version and copy them to the E2B USB drive \_ISO\WINDOWS\INSTALLS\APPS folder.

You can then either install them directly from the USB drive, or copy the .exe or .msi files to the C:\DRIVERS folder, and install them from the hard disk. 
To install them silently, use this syntax (examples for 7z and Foxit Reader):

start /wait msiexec /qb- /i %USB%\_ISO\WINDOWS\INSTALLS\APPS\7zip\BOTH\7z1602.msi

or if you copy them to the C:\DRIVERS folder...

start /wait C:\DRIVERS\FoxitReader734_enu_Setup_Prom.exe /silent

e.g. To add Foxit Reader:
\_ISO\WINDOWS\INSTALLS\APPS\Foxit\BOTH\FoxitReader734_enu_Setup_Prom.exe
\_ISO\WINDOWS\INSTALLS\APPS\Foxit\BOTH\FoxitReader.cmd    <---- contains command to install Foxit

To copy the whole folder, add this line to your \_ISO\WINDOWS\INSTALLS\CONFIGS\xxxxx.cmd file:
xcopy /herky %USB%\_ISO\WINDOWS\INSTALLS\APPS\Foxit\BOTH\ %systemdrive%\DRIVERS\ > nul

then the .cmd file will automatically be run by the code lines in startup.cmd, e.g. 
:: Install any apps we have added - run all .cmd files in DRIVERS\APPS folder...
FOR %%I IN (C:\DRIVERS\APPS\*.cmd) DO CALL :loopbody %%I


Choco Offline
=============
You can create choco packages which can be installed by Chocolatey offline.
These choco packages can be placed in the \_ISO\WINDOWS\INSTALLS\APPS\CHOXBOX folder.
This is an easy way to obtain and add 100's of packages that will silently install.

See http://www.easy2boot.com/add-payload-files/windows-install-isos/sdi-choco/chocbox/


DRIVERS folder
==============
This folder can contain machine-specific drivers for different systems.
Note: This folder is NOT anything to do with Snappy Driver Installer.

The correct drivers should be copied to C:\DRIVERS by your main config script (e.g. 904_W10.cmd).
The drivers can then be installed from the C:\DRIVERS folder (use subfolders).
Use Start /wait when installing drivers that run a Windows .exe program (e.g. start \wait C:\DRIVERS\Audio\setup.exe -s)

SNAPPY Folder
=============
This folder contains the Snappy Driver Installer application and any DriverPacks.
All required Driverpacks must be added first before you start an installation.
You should first run SDI_auto.bat and download at least the Index, chipset and network driver packs.
If you wish, you can download any of the other packs too (depending on what you think you will need).

wsusoffline folder
==================
This folder is used for WSUS Offline Updater files. Just download and copy the WSUS Offline Update files to this folder.
Run the WSUS utility UpdateGenerator.exe to download the desired update packs first, before you boot to E2B.

INSTALLCHOCO folder
===================
This folder is only used if you use Offline Choco installation packages (if OfflineChoco.tag is present).
It should contain the Chocolatey .nupkg package file plus scripts that are used to install Chocolatey.
http://www.easy2boot.com/add-payload-files/windows-install-isos/sdi-choco/chocbox/


