
Must be run from a folder on the E2B USB drive.

You can move or rename this folder but it MUST be on the USB drive somewhere.

Tip: Run as admin if it doesn't work as standard user.

Protect.cmd
===========
It encrypts the target file using LZMA compression
It sets the SYSTEM and HIDDEN ATTRIBUTES
It sets access permissions to Administrator only

You can rename Protect.cmd and the Protect folder to make it less obvious to other users.

You can edit the GROUP variable so that the target file will only be accessible on your system and your user account.

Protect_E2B_Files.cmd
=====================
Protect or unprotect a list of files on the E2B USB drive
Must be run from E2B USB drive.

Reset_Permissions_on_Drive.cmd
==============================
Resets permissions of all files to current Owner and all Users
DO NOT SHIP TO USERS!
Can be run from any location - e.g. Windows Desktop.
Requires Vista+ OS (not XP).


See www.easy2boot.com/configuring-e2b/protection-and-security/
for more details.
