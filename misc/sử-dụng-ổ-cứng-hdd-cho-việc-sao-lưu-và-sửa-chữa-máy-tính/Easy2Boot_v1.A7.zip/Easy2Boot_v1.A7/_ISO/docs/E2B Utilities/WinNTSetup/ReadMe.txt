Download WinNTSetup 3.8.7 Beta 4 or later from http://www.msfn.org/
Copy all folders to here.

This folder contains example diskpart .txt script files.

If the file .\WinNTSetup\tools\diskpart\enabled=1 exists, then you can press CTRL+SHIFT+D in WinNTSetup and run a diskpart script.

Tip: Move the whole WinNTSetup folder to the root of the E2B drive so that it is easier to find.

See http://www.easy2boot.com/add-payload-files/windows-install-isos/winntsetup/ for more details.
