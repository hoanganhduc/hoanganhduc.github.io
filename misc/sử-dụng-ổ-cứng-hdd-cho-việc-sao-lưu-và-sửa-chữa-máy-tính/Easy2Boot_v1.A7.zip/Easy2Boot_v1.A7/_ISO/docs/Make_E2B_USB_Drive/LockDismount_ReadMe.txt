LICENSE AND TERMS OF USE
------------------------


This License and Terms apply to the software called LockDismount.

IF YOU DISAGREE WITH THESE TERMS, DO NOT USE THIS SOFTWARE!

By accepting these license terms you are granted the following rights:

a) LICENSERANGE:  This Software is licensed, not sold. You may:
# use and distribute (by offer a download, CD, USB-Stick or any other storage medium) any number of copies of this software. Limitations please see Section b)
# use this software at home and at work within applicable law for legal purposes only.

b) You are not allowed:
# to sell, rent, lease or lend, reverse engineer, disassemble or decompile this software
(the term "to sell, rent, lease or lend" includes any storage medium (also offer a charged download) which are (going to / will be) produced for commercial purposes.)
# to grant any additional rights to a third party

c) DISCLAIMER OF WARRANTY.   THE SOFTWARE IS PROVIDED (LICENSED) "AS IS."  YOU TAKE THE RISK OF USING IT.  THE AUTHOR GIVES NO EXPRESS WARRANTIES, GUARANTEES OR CONDITIONS. THE AUTHOR CANNOT BE HELD RESPONSIBLE FOR ANY DAMAGE THAT MAY OCCUR BY USING THIS SOFTWARE! IF YOUR LOCAL APPLICABLE LAW ALLOWS YOU TO CANCEL ANY LIMITATIONS MADE UNDER SECTION B) AND/OR C) WITHIN THIS SOFTWARE LICENSE TERMS, AND IF YOU STILL WANT TO USE THIS SOFTWARE YOU EXPLICIT WAIVE YOUR RIGHT AGAINST THE AUTHOR!

d) You cannot claim any support service for this software. Any support given by the author are voluntarily and can be stopped without giving reason at any time.
