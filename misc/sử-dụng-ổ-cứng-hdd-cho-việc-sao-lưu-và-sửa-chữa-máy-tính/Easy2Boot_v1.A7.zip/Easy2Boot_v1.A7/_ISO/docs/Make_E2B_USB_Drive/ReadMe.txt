(linux users - please read the \_ISO\docs\linux_utils\ReadMe_fmt.sh.txt file)

To make a new Easy2Boot USB Flash drive (for Windows OS):

1. Insert your USB Flash drive into your computer's USB port
2. Right-click on the Make_E2B_USB_Drive.cmd file and choose 'Run as Administrator...'
3. Answer the prompts to format your USB Flash drive and install the Easy2Boot files.

4. To add your ISO files, simply copy them to the correct folder on your Easy2Boot USB drive.
e.g. Copy any ISOs that you want to appear in the first Main menu to \_ISO\MAINMENU  (except Windows Install ISOs)
     Copy linux ISOs to \_ISO\LINUX
     Copy Windows Install ISOs to correct folder under \_ISO\WINDOWS (e.g. Windows 7 ISOs --> \_ISO\WINDOWS\WIN7 folder)

5. Always run \MAKE_THIS_DRIVE_CONTIGUOUS.cmd (or RMPrepUSB-CTRL+F2) to run WinContig before testing the USB Flash drive.

See www.easy2boot.com for more details.
