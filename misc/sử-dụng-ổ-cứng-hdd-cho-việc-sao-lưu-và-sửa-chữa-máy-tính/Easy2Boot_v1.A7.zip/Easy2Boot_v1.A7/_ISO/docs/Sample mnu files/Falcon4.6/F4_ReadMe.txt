Falcon 4 UBCD (F4UBCD-4.61.iso)
===============================

F4UBCD-4.61.isoHW - To just run miniXP, a simple method is to just rename the file with a .isoHW file extension (MSDaRT will not work though without \BOOT folder).

For best method, convert ISO to .imgPTN file by drag-and-drop onto MPI_FAT32 Desktop shortcut
See http://rmprepusb.blogspot.co.uk/2014/06/add-multiple-hirens-isos-to-easy2boot.html for more details.

OR, 

you can use the .mnu file and the .lst file and extract some of the folders from the .iso file (the .iso file is not required on the E2B drive)


If you want to access RAID drives or other HDDs using F4 MiniXP:

1. Copy F4UBCD-4.61.iso to \_ISO\WINDOWS\XP folder
2. Ensure you are using E2B+DPMS version
3. Boot to E2B - Windows Installer Menu - XP - Step 1
4. Use defaults to answer questions
5. No need to press F6

