This Theme uses a GFXMenu file.
Copy the message and MyE2B.cfg file to the \_ISO folder.

You also need to copy the all ZZGFX_SubMenuXXX.mnu files in the   \_ISO\docs\GFXSubMenu Files   folder to the \_ISO\MAINMENU folder.

The ZZGFX_SubMenuXXX.mnu files are required for a GFXMenu as they do not have hotkeys assigned - GFXMenu does not support the grub4dos hotkey function.

If you wish, you can delete the existing ZZSubMenuXXXX.mnu files if you are not going to use a non-GFXMenu ever again.

For more details, see www.easy2boot.com

