MakePartImage.cmd runs on Windows XP or later systems. a Linux version is not available.

SUMMARY
=======

MakePartImage.cmd is a utility to make FAT32 or NTFS Partition image files for use with Easy2Boot.

Typically you will just drag-and-drop an .ISO file onto the MPI_FAT32 Desktop shortcut to make a .imgPTN file.

Desktop Shortcuts
=================
MPI_FAT32     - runs the MakePartImage_AutoRun_FAT32.cmd 
MPI_NTFS      - runs the MakePartImage_AutoRun_NTFS.cmd 
MakePartImage - runs the MakePartImage.cmd script

Drag-and-drop an ISO or folder onto a shortcut and it will automatically make a .imgPTN file in the same folder as the ISO.

Action of MakePartImage
=======================
MakePartImage creates a partition on a virtual drive volume (ramdisk) using ImDisk. It then formats it,
copies over the files from an ISO or the folder/source that you specify, and then adds a menu.lst, grub4dos bootloader file grldr and other files used for the CSM Menu system.
If required, syslinux is installed onto the ramdrive volume PBR and boot configuration files are changed for USB booting instead of CD booting.
Then the ramdrive volume is dismounted to leave the new image file.
You can then copy the image file to your E2B USB drive.

MakePartImage does not need to recognise which type of payload you are using, it modifies the boot configuration files in a generic manner.


QUICK INSTALL INSTRUCTIONS
==========================

1. Unzip this MPI Tool Pack to a new folder on your Windows system (e.g. C:\MPI)
2. Run .\ImDisk\imdiskinst.exe
3. Download and install WinRAR (optional, but recommended)
4. Run .\CreateDesktopShortcuts.cmd to create the three Desktop shortcuts
5. Drag-and-drop any .iso file or source folder onto the MPI_FAT32 Desktop shortcut to make a .imgPTN file
6. Copy the .imgPTN file to your Easy2Boot USB drive (e.g. \_ISO\MAINMENU\)


FULL INSTRUCTIONS
=================

1. Copy this folder to a new folder onto your Windows system's hard disk (e.g. Dekstop). Do NOT copy this folder to a USB drive.

2. You need to install ImDisk first. To install ImDisk, double-click on .\ImDisk\imdiskinst.exe and run as Administrator

   For some UDF ISOs, you may also need to install either PowerIso or WinRAR.

   Note: You can add your own menu.lst file and background bitmap, etc. by placing them in the CUSTOM folder before you run MakePartImage.
   If adding a .\CUSTOM\menu.lst file, you MUST base it on .\csm\menu.lst (use it as a template).
   You can add .\CUSTOM\MyCSM.cfg configuration file and background bmp file (made using E2B_Editor.exe)
   Make sure 'set HEADING=' is used in MyCSM.cfg so that the HEADING is empty/blank.

   If you add a GFXBoot menu file to .\CUSTOM\e2b\message, then it will always be used for the menu.

   The language can be changed by using 'set LANG=GERMAN' in the .\CUSTOM\MyCSM.cfg file (file must start with !BAT on first line). 
   Other languges may be avaiable later (check the csm\e2b\LANG folder for other languages).

3. You must run MakePartImage as Administrator. Right-click on MakePartImage.cmd and run as Administrator

  Tip: To create 3 Desktop shortcut icons - double-click on CreateDesktopShortCuts.cmd  (see below if you have XP with no vbscript support)
  
       3 Desktop Shortcuts are made:
	   
       MakePartImage.lnk - runs MakePartImage.cmd with admin rights
       MPI_FAT32.lnk     - runs MakePartImage automatically, set to FAT32 with admin rights
       MPI_NTFS.lnk      - runs MakePartImage automatically, set to NTFS with admin rights
	   
	You can drag-and-drop an ISO file or folder onto the Desktop Shortcut to make an image file.

4. If you run MakePartImage.cmd manually, it will prompt you for the ISO or folder name. 

Enter the full path and name of the ISO (or drive/folder) - examples of valid paths are:

  C:\temp\pmagic.iso
  "C:\folder with spaces\pmagic.iso"
  J:\						(note that you must use \ if specifying a whole drive)
  C:\TEMP\KONBOOT

  Tip: Use the TAB key for path completion, this will automatically add double-quotes if needed.
  
 5. Now answer the questions when prompted. Usually you will just need to press [Enter] to accept the defaults.
 
 Use FAT32/NTFS             (press [Enter] for FAT32)
 Size for Image File        (press [Enter] for suggested default size)
 OUTPUT FILENAME            (press [Enter] to create a file in the same folder as the ISO - otherwise change it) - YOU MUST NOT OMIT a file extension - e.g. C:\temp\fred.imgPTN or C:\temp\fred.NOEXT
 (answer any more questions here - if unsure, just press [Enter]
 (if required you can edit the mounted image now before it is saved)
 
 6. Press [Enter] to save and dismount the ramdrive (usually U:)
 
 (if required, answer any more questions)

If the image file was made successfully, an Explorer window containing the file should open.

 7. Finally, copy the file to the \_ISO\MAINMENU folder of your E2B USB drive (or any of the menu folders).
    Ensure the extension is .imgPTN or one of that family (e.g. .imgPTNLBAa).
    Ensure you run WinContig on the USB drive (RMPrepUSB - Ctrl+F2).
    (optional) create a .txt file for the menu entry title (see Easy2boot.com for more details).
    Boot from the E2B drive and choose the image file.

	
   ---------     MakePartImage Command line    ---------------

MakePartImage.cmd can be run from the command line also:

Usage:   [iso_to_extract | folder]   [IMG_to_create]  [FAT32 | NTFS]  [size (MB)]   {volume_label}  {title]

iso_to_extract | folder   = an ISO file or a folder path or drive letter:\
IMG_to_create             = path and name of the image file you want to make.
size                      = size in MB of the image file you want to create.
volume_label (optional)   = some EFI FAT32 implementations may require a particular volume label for the FAT32 volume - default=LIVE.
title                     = the title to use for the menu. If an ISO file was used, this will be set to the file name automatically.

Remember to use double-quotes for paths and file names if they contain spaces!

Examples:

Recommended:
MakePartImage "C:\temp\ubuntuamd6.iso"  *  FAT32 *   <- uses same folder to save file and use suggested size and Volume Name

Other examples:
MakePartImage "C:\temp\somesmall.iso"  "C:\temp\NEW.imgPTN" FAT32 200
MakePartImage  C:\temp\somedir          C:\temp\NEW.imgPTN  NTFS  200  myvol
MakePartImage "C:\temp\ubuntuamd6.iso" "C:\temp\NEW.imgPTN" FAT32 780  "UbuntuEFI"
MakePartImage "C:\temp\ubuntuamd6.iso" "C:\temp\NEW.imgPTN" FAT32 780  "UbuntuEFI" "My NEW image"
MakePartImage "C:\temp\ubuntuamd6.iso"                                             <- you will be prompted for any missing parameters
MakePartImage "C:\temp\ubuntuamd6.iso" "C:\temp\NEW.imgPTN" FAT32                  <- you will be prompted for any missing parameters
MakePartImage "C:\temp\ubuntuamd6.iso"  *                   FAT32                  <- use same folder to save file and ask for size


DESKTOP SHORTCUTS
=================

   Tip: Create a shortcut on your Desktop and set Properties - Advanced - Run as Administrator
   
   To make it work with pathnames with spaces in them, add    cmd.exe /c     in front of the Target text: e.g.
   Target:   cmd.exe /c C:\temp\MakePartImage\MakePartImage.cmd
   Note: Do NOT use double-quotes for the WHOLE path. If you have spaces in the path use double-quotes like this:
             cmd.exe /c F:\"temp\folder with spaces\MakePartImage\MakePartImage.cmd"
   Note the position of the first " is after the drive letter and \. Now you can drag-and-drop any ISO file onto the shortcut.

SPLIT_WINISO
============
This program was created by Chandra. It is used to split large Windows Install ISOs which contain >4GB Install.wim or Install.ESD files so that a FAT32 .imgPTN file can be created for UEFI booting.
It can also be used to inject startup files into the boot.wim so that you can select multiple XML files from within one .imgPTN file.
After modifiying the .wim files, Split_WinISO will run MakePartImage for you to make a .imgPTN file, or you can choose to make a .ISO file instead or a .imgPTN file.

See Split_WinISO_Readme.txt for more details.


