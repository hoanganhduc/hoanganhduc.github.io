
	    .d8888b.           888 d8b 888         888       888 d8b          8888888 .d8888b.   .d88888b.  
	   d88P  Y88b          888 Y8P 888         888   o   888 Y8P            888  d88P  Y88b d88P" "Y88b 
	   Y88b.               888     888         888  d8b  888                888  Y88b.      888     888 
	    "Y888b.   88888b.  888 888 888888      888 d888b 888 888 88888b.    888   "Y888b.   888     888 
	       "Y88b. 888 "88b 888 888 888         888d88888b888 888 888 "88b   888      "Y88b. 888     888 
	         "888 888  888 888 888 888         88888P Y88888 888 888  888   888        "888 888     888 
	   Y88b  d88P 888 d88P 888 888 Y88b.       8888P   Y8888 888 888  888   888  Y88b  d88P Y88b. .d88P 
	    "Y8888P"  88888P"  888 888  "Y888      888P     Y888 888 888  888 8888888 "Y8888P"   "Y88888P"  
	              888                                                                                   
	              888                                                                                   
	              888                                                                                   

                	                        .:[ EASY2BOOT COMPATIBLE ]:.
        	                             ==================================
                                                      www.easy2boot.com


Split WinISO.exe-for conversion, merging and splitting of Windows 7/8.1/10 Install ISOs and >4GB Install.wim files

==================================================================================================================

Version History :
=================

Version : 1.0.0 (2017-03-03) release
Version : 1.0.1 (2017-03-04) change display
Version : 1.0.2 (2017-03-05) Back to the initial setting using drive letter U:
Version : 1.0.3 (2017-03-05) Bug fixes in the form Split_WIM cleared on first run, 
Version : 1.0.4 (2017-03-06) minor bug fixes (in the process split the folder \x86 and \x64 and update dll files) 
Version : 1.0.5 (2017-03-07) Improved methods to convert file ESD using automatically, change compressor to LZX
                             and LZMS, add version number and date, new feature to support different source in 
                             one iso.
Version : 1.0.6 (2017-03-11) FIX BUG Allow spaces in path and file name
Version : 1.0.7 (2017-03-12) Reconfiguration to synchronize better with MPI Tool Pack.
Version : 1.0.8 (2017-03-16) 1. Automatic detection windows7x64 image if the efi folder does not exist, and
                                the file will be added bootx64.efi to support UEFI boot before created ISO or
                                imgPTN.
                             2. Using two compressors Wimlib.Imagex (Open Source) and DISM (official MS). This is
                                done because it found cases, double the index name in the image file windows AIO,
                                if converted using Wimlib.Imagex will happen ERROR and solutions using DISM, while
                                for single iso image, any selection is no problem.
                             3. For Windows AIO especially ESD file will have the option to use this type of 
                                compressor Wimlib.Imagex or DISM.
                             4. Changes in the selection of options that will be used File System (NTFS & FAT32),
                                which was originally Yes for the NTFS and NO for FAT32, changed of Yes for FAT32
                                and NO for NTFS.
                             5. Repair Help Text with two option (read using Notepad and read directly from the
                                application.
Version : 1.0.9 (2017-03-17) 1. Improved automatic detection of the window 7x64
                             2. If there are corrupt during the conversion process or the cancellation process by
                                the user, the column selection does not do the cleaning, so users no longer have
                                to search again.
Version : 1.1.0 (2017-03-28) 1. Changes to the theme (including icons, and buttons)
                             2. Addition Column Image (value index)
                             3. Additional features View Info (description of all the files installed)
                             4. Detection of applications already open.
Version : 1.1.1 (2017-03-30) 1. Repair of engine speed to copy the folder extract (Path button)
                             2. Repairs error detection large windows ISOs 32+64 (AIO).
                             3. Elimination nircmd.exe as supporting files.
                             4. Repair process of gathering information of the image file (View Button)
Version : 1.1.2 (2017-04-10) 1. Minor bug fixes and re-source code management
                             2. AutoUnattendBlank.xml replacement by a new version due to the old version does
                                not work.
Version : 1.1.3 (2017-04-28) 1. Minor bug fixes and re-source code management
                                repair error script if user cancel to extract or copy file images
==================================================================================================================
==================================================================================================================

Description :

This Windows tool will convert Windows Install ISO files containing large (>4GB) .ESD or .WIM files into a .ISO
file containing smaller split-wim (.SWM) files suitable for use on FAT32 filesystems.

Specification :
- Windows utility which can take a Windows Install ISO (or extracted folder) and convert it into another ISO 
  (or to an E2B FAT32 .imgPTN file if you have the Easy2Boot MPI Tool Kit installed). 
- The useful thing about this app is that it will split a large Install.WIM, Install.SWM or install.ESD file into 
  split SWM files automatically. THIS MEANS THAT THE RESULTING FILES CAN BE USED ON A FAT32 FILESYSTEM 
  (e.g. for UEFI-booting).
- Works on the Microsoft ISOs that contain both \x86 and \x64 folders (with two Install.ESD\WIM files)
- Converts SWM\ESD\WIM to .SWM automatically.
- Easy2Boot compatible - just copy the .exe file into the MPI ToolKit folder and run it from there
- Do not run two or more instances simultaneously as it will make the system crash and the engine load is very
  high resource.
- Compressor to Convert ESD, split WIM and merge SWM file. LZD and LZMS compression gives best performance
- Supports converting mixed Install.ESD and Install.WIM files when found in same ISO.
- Portable application (no installation required)

Supports official MS ISOs 
1. x86\sources\install.esd + x64\sources\install.esd
2. x86\sources\install.wim + x64\sources\install.wim
3. x86\sources\install.swm + x64\sources\install.swm
4. install.esd
5. install.wim
6. install.swm

Supports All-in-One ISOs (AIO)
1. x86\sources\install.esd + x64\sources\install.wim
2. x86\sources\install.esd + x64\sources\install.swm
3. x86\sources\install.wim + x64\sources\install.esd
4. x86\sources\install.wim + x64\sources\install.swm
5. x86\sources\install.swm + x64\sources\install.esd
6. x86\sources\install.swm + x64\sources\install.wim

NORMAL USE
==========

CONVERT Button Function: (ISO or the extracted folder)
1. ESD files -> converted into a large WIM files -> split into small SWM files -> create New ISO or imgPTN (FAT32)
2. ESD files -> converted into a WIM files -> create New ISO or imgPTN (FAT32)
3. Large Wim files -> split into small SWM files -> create a new ISO or imgPTN (FAT32)
4. Large SWM files -> merge into large WIM files -> re-split into smaller SWM files -> create New ISO or imgPTN
   (FAT32)
5. Small SWM files -> merge into small WIM files -> create New ISO or imgPTN (FAT32)

Program action:
1. Extract files from ISO or DVD/CD/Folder
2. Convert ESD files (if present) into WIM files and then split into smaller SWM files.
3. Merge large SWM files (if present) into WIM files and then re-split into smaller SWM files.
4. Split any large WIM files into smaller SWM files.
5. Save as ISO file (or .imgPTN file for use with Easy2Boot)
6. (optional for Easy2Boot) Inject winpeshl.ini and Mysetup.cmd into boot.wim

Because all files will be less than 4GB, they can now be UEFI-booted from a FAT32 drive volume.

REQUIREMENTS:
=============
1. A Win 7/8/10 system is required.
2. ImDisk - download and install imdisk. http://www.ltr-data.se/opencode.htmI/#ImDisk
3. Administrator access rights required.
4. Use official Microsoft Windows 7/8/8.1/10 Install ISOs.
5. 32-bit + 64-bit combined ISOs are supported.
6. Multiple-image ESD\WIM files are supported.
7. Requires drive U: to be a free drive letter

Convert to ISO:
==============
1. Select source - use the ISO button or the PATH button to select a DVD/Folder containing Windows Installer files.
2. The size and type of ESD\WIM files should now be displayed:
   x86  = \x86\Sources\Install.* size+type (ESD\WIM)
   x64  = \x64\Sources\Install.* size+type (ESD\WIM)
   BOTH = \Sources\Install.*     size+type (ESD\WIM)
3. Set the Split Size in MB, between 3-5 digit (e.g. 4000). For FAT32, do not exceed 4000.
4. Press the 'CONVERT' Button.


USE WITH EASY2BOOT (www.easy2boot.com)
======================================
1. The Easy2Boot MPI Tool Pack is required
2. Copy this application .exe file into the MPI Tool Pack folder and run it.
   You should now see a new MPI button as well as the CONVERT button.

CONVERT - converts large ESD\WIM files, you can save it as a FAT32 .imgPTN for Easy2Boot or as an .ISO file.
MPI     - save as FAT32 or NTFS .imgPTN file but DOES NOT SPLIT LARGE FILES

Modification of boot.wim (optional):
======================================
1. Both the CONVERT and MPI buttons will also offer you the option to add the files MySetup.cmd and Winpeshl.ini
   into the boot.wim image #2 (Setup) file.
2. Some sample .XML files and the \Auto.cmd will also be copied to the root of the USB drive. These will require 
   changing by the user before use.
3. This allows the user to choose from a selection of XML files (e.g. to install Home or Pro, etc.).
   For more details, see http://www.easy2boot.com/add-payload-files/automating-windows-install-from-imgptn-files

NOTES
=====
1. Some antivirus and firewalls may block this tool. Please disable or whitelist as required.

2. Some Microsoft ISOs may not support split WIM files. See: https://msdn.microsoft.com/en-us/windows/hardware/
   commercialize/manufacture/desktop/split-a-windows-image--wim--file-to-span-across-multiple-dvds
   If you find such an ISO, please use WinNTSetup instead.

3. When converting a .ESD to .WIM, the process will consume very high amounts of CPU and RAM resources which may 
   drastically slow down your system.

4. '[WARNING] Failed to enable short name support� - this warning is normal and can be ignored.

THANKS tO:
==========
1. Steve Si (www.easy2boot.com)
2. Olof Lagerkvist (http://www.ltr-data.se)
3. Abbodi1406 & Synchronicity

Best Regards "Chandra (orbitsolusi.com)"
