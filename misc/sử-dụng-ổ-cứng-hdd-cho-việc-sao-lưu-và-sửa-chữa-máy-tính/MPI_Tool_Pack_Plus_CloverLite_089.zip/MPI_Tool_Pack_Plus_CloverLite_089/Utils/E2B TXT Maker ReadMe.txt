http://rmprepusb.blogspot.co.uk/2014/02/how-to-quickly-make-easy2boot-txt-and.html

E2B TXT Maker.cmd   - generates an Easy2Boot .txt file

The easiest way to use E2B TXT Maker is to first copy the .cmd file to your Windows Desktop.

Now to make a .txt file for any payload file on your E2B USB drive, 
simply Drag-and-Drop the payload file (e.g. xxxxx.imgPTN) onto the E2B TXT Maker.cmd icon that is now on your Desktop.

The script will then ask you what menu text and help text you want and make a .txt file (in the same folder as the payload file) on your E2B USB drive. 

You can specify a hotkey key by using ^^ before the keyname (^^ will be translated into ^ when the file is made).
