Restore E2B partition(s) - 32-bit only
======================================
SWITCH_E2B.exe - Restore E2B Partitions (recommended)
RestoreE2B (run as admin).cmd
FindCSMandRestoreE2B.cmd  (can use with command line parameter SURE in a batch file to run unattended with no user prompts)
MbrFix_E2B.exe  (Emergency use only - no checks made!)

Restore E2B partition(s) - 64-bit only
======================================
MbrFix_E2B_64.exe  (Emergency use only - no checks made)


Menu files (do not edit)
========================
centrehd.g4b   (grub4dos batch fiel to centre menu headings)
CSM.bmp.gz     (default menu wallpaper)
CSM_Menu.g4b   (grub4dos batch file to assist with CSM.cfg menu config file)
hotkey         (grub4dos utility to support menu hotkeys)
menusetting.gz (grub4dos utility to position menu items)
setHPAD.g4b    (grub4dos menu helper batch file)
unifont.hex.gz (grub4dos font file)

SDI_CHOCO files
===============
*.XML files   (example files for use with SDI_CHOCO Windows installations)
STAGE1.cmd and STAGE2.cmd (used with SDI_CHOCO Windows Installs)
Unattend.xml  (used by SDI_CHOCO installs to run Stage1.cmd)

Other files
===========
MBR.BIN       (for original MBR backup)
MSVBVM60.DLL  (Visual Basic 6 DLL used by RMPartUSB and SWITCH_E2B.exe)
RMPARTUSB.exe (32-bit executable for partitioning/preparing USB drives)
RestoreCSM (run as admin).cmd (restore CSM-menu MBR if you accidentally changed to E2B MBR)





